# Regenera las imágenes de 02-proceso-foto/ a partir de los WebP del sitio y la captura original.
# Uso (desde la carpeta virginia-neural): python3 recursos-virginia/03-scripts/procesar_capas.py
from pathlib import Path
from PIL import Image, ImageOps

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "recursos-virginia" / "02-proceso-foto"
OUT.mkdir(parents=True, exist_ok=True)
REF = ROOT / "recursos-virginia" / "01-referencias-originales" / "Captura_de_Pantalla_2026-10-21_a_la_s_15.33.49.png"

ref = Image.open(REF).convert("RGB")
w, h = ref.size
s = min(w, h)
crop = ref.crop(((w - s) // 2, 0, (w - s) // 2 + s, s)).resize((1024, 1024), Image.LANCZOS)
crop.save(OUT / "01-referencia-recorte.png", optimize=True)

col = Image.open(ROOT / "src/assets/virginia-portrait.webp").convert("RGBA").resize((1024, 1024), Image.LANCZOS)
bg = Image.new("RGBA", col.size, (2, 6, 23, 255))
Image.alpha_composite(bg, col).convert("RGB").save(OUT / "02-color-con-transparencia.png", optimize=True)

dep = Image.open(ROOT / "src/assets/virginia-depth.webp").convert("L").resize((1024, 1024), Image.LANCZOS)
dep.save(OUT / "03-profundidad.png", optimize=True)
ImageOps.colorize(dep, black="#020617", mid="#0ea5e9", white="#fcd34d").save(OUT / "04-profundidad-color.png", optimize=True)

alpha = col.split()[3].convert("RGB")
side = Image.new("RGB", (512 * 3, 512), (2, 6, 23))
for i, im in enumerate([Image.alpha_composite(bg, col).convert("RGB"), alpha, dep.convert("RGB")]):
    side.paste(im.resize((512, 512), Image.LANCZOS), (512 * i, 0))
side.save(OUT / "05-capas-lado-a-lado.png", optimize=True)
print("listo:", sorted(p.name for p in OUT.iterdir()))
