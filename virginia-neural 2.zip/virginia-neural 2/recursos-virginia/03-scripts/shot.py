# Captura del retrato de Virginia en escritorio y móvil + FPS.
# Uso: python3 shot.py [ms_espera]   (requiere el sitio en http://localhost:8080)
import asyncio, sys
from pathlib import Path
from playwright.async_api import async_playwright

OUT = Path(__file__).parent / "capturas"
OUT.mkdir(exist_ok=True)

async def main():
    wait = int(sys.argv[1]) if len(sys.argv) > 1 else 9000
    async with async_playwright() as p:
        b = await p.chromium.launch(headless=True, args=["--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader"])
        for (w, h, name) in [(1440, 900, "desk"), (390, 844, "mob")]:
            ctx = await b.new_context(viewport={"width": w, "height": h})
            page = await ctx.new_page()
            logs = []
            page.on("console", lambda m: logs.append(f"{m.type}: {m.text}"))
            page.on("pageerror", lambda e: logs.append(f"pageerror: {e}"))
            await page.goto("http://localhost:8080", wait_until="networkidle")
            await page.wait_for_timeout(wait)
            await page.screenshot(path=str(OUT / f"{name}.png"))
            fps = await page.evaluate("() => new Promise(r=>{let c=0;const t0=performance.now();function f(){c++; if(performance.now()-t0<2000) requestAnimationFrame(f); else r(c/2)} requestAnimationFrame(f)})")
            print(name, "fps", fps)
            if name == "desk":
                for label in ["Sonrisa", "Sorpresa"]:
                    await page.get_by_role("button", name=label, exact=True).click()
                    await page.wait_for_timeout(4000)
                    await page.screenshot(path=str(OUT / f"desk_{label.lower()}.png"))
                await page.get_by_role("button", name="Paleta Neural Emerald").click()
                await page.wait_for_timeout(1500)
                await page.screenshot(path=str(OUT / "desk_emerald.png"))
            print(name, [l for l in logs if "error" in l.lower()][:8])
            await ctx.close()
        await b.close()

asyncio.run(main())
