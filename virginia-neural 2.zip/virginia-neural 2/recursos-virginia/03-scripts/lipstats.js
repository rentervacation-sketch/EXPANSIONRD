// Pegar en la consola del navegador con el sitio abierto (modo dev).
// Cuenta cuántos puntos de la zona de boca son "piel" vs "labio" según el rojo relativo (r-g)/r.
const m = await import("/src/lib/virginia/portrait.ts");
const src = await m.loadPortraitSource(640);
const F = m.generate(src, 26000);
const out = {};
for (let i = 0; i < F.kind.length; i++) {
  if (F.kind[i] !== m.KIND.lip) continue;
  const r = F.color[i * 3], g = F.color[i * 3 + 1];
  const rg = (r - g) / Math.max(r, 1e-3);
  const bin = rg < 0.35 ? "piel" : rg < 0.41 ? "intermedio" : "labio";
  out[bin] = (out[bin] || 0) + 1;
}
console.table(out);
