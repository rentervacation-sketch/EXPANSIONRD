/*
 * VIRGIN.IA — Face Mesh 3D procedural
 * ---------------------------------------------------------------------------
 * Genera un rostro femenino estilizado como campo de dots (rejilla hexagonal)
 * con profundidad real (z), regiones animables (ojos, labios, mandíbula),
 * sombreado precalculado y una lista de aristas para dibujar la malla.
 *
 * No depende de modelos externos ni de red: todo es paramétrico y determinista.
 * Lo consumen el motor WebGL (virginia-home-neural.js) a través de
 * window.VirginiaFace.
 *
 * Espacio del rostro (sin escala): x ∈ [-0.8, 0.8], y ∈ [-1.15, 1.05], z ∈ [0, ~0.6].
 */
(function (root) {
  'use strict';

  const sstep = (a, b, x) => {
    const t = Math.min(1, Math.max(0, (x - a) / (b - a)));
    return t * t * (3 - 2 * t);
  };
  const gauss = (x, y, cx, cy, sx, sy) => Math.exp(-(((x - cx) / sx) ** 2 + ((y - cy) / sy) ** 2));

  // Contorno del rostro: elipse con mandíbula que se estrecha hacia el mentón.
  function inside(x, y) {
    const yy = y >= 0 ? y / 1.05 : y / 1.15;
    const taper = 1 - 0.3 * sstep(-0.15, -1.15, y);
    const w = 0.8 * taper;
    return (x / w) ** 2 + yy * yy <= 1;
  }

  // Altura (profundidad) del rostro en (x, y).
  function depth(x, y) {
    const dome = 0.42 * Math.sqrt(Math.max(0, 1 - (x / 0.92) ** 2 - ((y - 0.05) / 1.4) ** 2));
    let z = dome;
    z += 0.1 * gauss(x, y, 0, 0.38, 0.6, 0.07); // arco superciliar
    z -= 0.11 * (gauss(x, y, -0.36, 0.22, 0.15, 0.085) + gauss(x, y, 0.36, 0.22, 0.15, 0.085)); // cuencas
    z += 0.05 * (gauss(x, y, -0.36, 0.22, 0.07, 0.04) + gauss(x, y, 0.36, 0.22, 0.07, 0.04)); // iris
    z += 0.1 * gauss(x, y, 0, 0.05, 0.07, 0.28); // puente nasal
    z += 0.17 * gauss(x, y, 0, -0.3, 0.09, 0.09); // punta de la nariz
    z += 0.06 * (gauss(x, y, -0.14, -0.33, 0.06, 0.05) + gauss(x, y, 0.14, -0.33, 0.06, 0.05)); // alas
    z -= 0.04 * (gauss(x, y, -0.07, -0.36, 0.03, 0.03) + gauss(x, y, 0.07, -0.36, 0.03, 0.03)); // fosas
    z += 0.06 * (gauss(x, y, -0.52, -0.08, 0.2, 0.14) + gauss(x, y, 0.52, -0.08, 0.2, 0.14)); // pómulos
    z += 0.07 * gauss(x, y, 0, -0.62, 0.2, 0.05); // labio superior
    z += 0.08 * gauss(x, y, 0, -0.78, 0.19, 0.06); // labio inferior
    z -= 0.05 * gauss(x, y, 0, -0.7, 0.2, 0.012); // línea de la boca
    z += 0.08 * gauss(x, y, 0, -0.98, 0.2, 0.1); // mentón
    return z;
  }

  // Genera la rejilla hexagonal con un espaciado dado.
  function lattice(spacing) {
    const rowH = spacing * Math.sqrt(3) / 2;
    const pts = [];
    const index = new Map();
    for (let r = 0, y = 1.06; y > -1.16; r += 1, y -= rowH) {
      const off = r % 2 ? spacing / 2 : 0;
      for (let c = 0, x = -0.85 + off; x < 0.85; c += 1, x += spacing) {
        if (!inside(x, y)) continue;
        index.set(r + ',' + c, pts.length);
        pts.push({ x, y, r, c });
      }
    }
    return { pts, index };
  }

  /**
   * @param {number} target  número deseado de dots del rostro (el real puede ser algo menor)
   */
  function generate(target) {
    let spacing = Math.sqrt(2.1 * 1.55 / Math.max(200, target));
    let grid = lattice(spacing);
    for (let k = 0; k < 4; k += 1) {
      const ratio = grid.pts.length / target;
      if (ratio > 0.97 && ratio <= 1) break;
      spacing *= Math.sqrt(ratio);
      grid = lattice(spacing);
    }
    while (grid.pts.length > target) {
      spacing *= 1.01;
      grid = lattice(spacing);
    }

    const n = grid.pts.length;
    const pos = new Float32Array(n * 3);
    const eyeW = new Float32Array(n);
    const eyeCy = new Float32Array(n);
    const mouthW = new Float32Array(n);
    const mouthSide = new Float32Array(n);
    const jawW = new Float32Array(n);
    const kind = new Uint8Array(n); // 0 piel · 1 ojo · 2 labio
    const shade = new Float32Array(n); // sombreado Lambert precalculado (luz arriba-izquierda)
    const lx = -0.35;
    const ly = 0.55;
    const lz = 0.75;
    const ll = Math.hypot(lx, ly, lz);

    for (let i = 0; i < n; i += 1) {
      const { x, y } = grid.pts[i];
      pos[i * 3] = x;
      pos[i * 3 + 1] = y;
      pos[i * 3 + 2] = depth(x, y);

      const h = 0.004;
      const gx = -2.2 * (depth(x + h, y) - depth(x - h, y)) / (2 * h);
      const gy = -2.2 * (depth(x, y + h) - depth(x, y - h)) / (2 * h);
      const nl = Math.hypot(gx, gy, 1);
      const lambert = Math.max(0, (gx * lx + gy * ly + lz) / (nl * ll));
      shade[i] = 0.28 + 0.95 * lambert;

      // Ojos (para el parpadeo).
      const eL = gauss(x, y, -0.36, 0.22, 0.15, 0.075);
      const eR = gauss(x, y, 0.36, 0.22, 0.15, 0.075);
      const e = Math.max(eL, eR);
      eyeW[i] = e > 0.35 ? Math.min(1, (e - 0.35) / 0.4) : 0;
      eyeCy[i] = 0.22;
      if (eyeW[i] > 0.3) kind[i] = 1;

      // Labios (para hablar): el superior sube, el inferior baja.
      const m = gauss(x, y, 0, -0.7, 0.26, 0.11);
      mouthW[i] = m > 0.3 ? Math.min(1, (m - 0.3) / 0.5) : 0;
      mouthSide[i] = y > -0.7 ? 1 : -1;
      if (mouthW[i] > 0.4) kind[i] = 2;

      // Mandíbula: acompaña la apertura de la boca.
      jawW[i] = sstep(-0.62, -1.1, y);
    }

    // Aristas de la malla triangulada (vecinos de la rejilla hexagonal).
    const edges = [];
    const idx = (r, c) => grid.index.get(r + ',' + c);
    for (let i = 0; i < n; i += 1) {
      const { r, c } = grid.pts[i];
      const right = idx(r, c + 1);
      if (right !== undefined) edges.push(i, right);
      const a = idx(r + 1, c);
      const b = idx(r + 1, r % 2 ? c + 1 : c - 1);
      if (a !== undefined) edges.push(i, a);
      if (b !== undefined) edges.push(i, b);
    }
    const edgeArr = new Uint32Array(edges);
    const rest = new Float32Array(edgeArr.length / 2);
    for (let e = 0; e < rest.length; e += 1) {
      const a = edgeArr[e * 2] * 3;
      const b = edgeArr[e * 2 + 1] * 3;
      rest[e] = Math.hypot(pos[a] - pos[b], pos[a + 1] - pos[b + 1], pos[a + 2] - pos[b + 2]);
    }

    return { count: n, spacing, pos, eyeW, eyeCy, mouthW, mouthSide, jawW, kind, shade, edges: edgeArr, rest };
  }

  /**
   * Rig de animación: mirada, parpadeo, boca y respiración. Entrega la posición
   * destino de cada dot. Los dots que sobran más allá del rostro forman un halo.
   */
  function createRig(F) {
    const rig = {
      face: F, yaw: 0, pitch: 0, blink: 0, blinking: false, blinkT: 0, nextBlink: 1.6,
      mouth: 0, speaking: false, S: 28, br: 1, cy: 1, sy: 0, cp: 1, sp: 0, tv: [0, 0, 0],
    };

    rig.prepare = function prepare(time, dt, mx, my, radius) {
      const k = Math.min(1, dt * 60 * 0.06);
      let ty;
      let tp;
      if (Math.abs(mx) > 4000) { // sin puntero: mirada de reposo
        ty = Math.sin(time * 0.45) * 0.2;
        tp = Math.sin(time * 0.33) * 0.07;
      } else {
        ty = Math.max(-0.55, Math.min(0.55, (mx / 90) * 0.5));
        tp = -Math.max(-0.32, Math.min(0.32, (my / 70) * 0.3));
      }
      rig.yaw += (ty - rig.yaw) * k;
      rig.pitch += (tp - rig.pitch) * k;
      rig.cy = Math.cos(rig.yaw); rig.sy = Math.sin(rig.yaw);
      rig.cp = Math.cos(rig.pitch); rig.sp = Math.sin(rig.pitch);

      if (!rig.blinking && time > rig.nextBlink) {
        rig.blinking = true; rig.blinkT = 0; rig.nextBlink = time + 2.2 + Math.random() * 3.6;
      }
      if (rig.blinking) {
        rig.blinkT += dt;
        const u = rig.blinkT / 0.2;
        if (u >= 1) { rig.blinking = false; rig.blink = 0; } else rig.blink = Math.sin(Math.PI * u);
      }

      const mouthTarget = rig.speaking
        ? Math.abs(Math.sin(time * 9.5)) * (0.55 + 0.45 * Math.sin(time * 3.3)) * 0.9
        : 0.04 + 0.03 * Math.sin(time * 0.8);
      rig.mouth += (mouthTarget - rig.mouth) * Math.min(1, dt * 60 * 0.25);

      rig.br = 1 + 0.012 * Math.sin(time * 1.4);
      rig.S = radius * 0.4 * rig.br;
    };

    rig.target = function target(i, time) {
      const t = rig.tv;
      const S = rig.S;
      if (i < F.count) {
        const k = i * 3;
        const x = F.pos[k] * S;
        let y = F.pos[k + 1] * S;
        const z = F.pos[k + 2] * S * 1.15;
        const ew = F.eyeW[i];
        if (ew > 0 && rig.blink > 0) y += (F.eyeCy[i] * S - y) * ew * rig.blink * 0.92;
        const mw = F.mouthW[i];
        if (mw > 0) y += F.mouthSide[i] * mw * rig.mouth * S * 0.075;
        const jw = F.jawW[i];
        if (jw > 0) y -= jw * rig.mouth * S * 0.05;
        const x1 = x * rig.cy + z * rig.sy;
        const z1 = -x * rig.sy + z * rig.cy;
        t[0] = x1;
        t[1] = y * rig.cp - z1 * rig.sp + 0.05 * S;
        t[2] = y * rig.sp + z1 * rig.cp;
        return t;
      }
      // Halo orbital alrededor de la cabeza.
      const j = i - F.count;
      const a = j * 2.399963 + time * (0.06 + (j % 9) * 0.012);
      const h = ((j * 0.754877) % 1) * 2 - 1;
      const rr = S * (1.45 + ((j * 0.618034) % 1) * 1.1) * Math.sqrt(1 - h * h * 0.85);
      t[0] = Math.cos(a) * rr;
      t[1] = h * S * 1.25;
      t[2] = Math.sin(a) * rr * 0.75 - S * 0.2;
      return t;
    };

    /** Explosión 3D: impulso radial desde el punto (ox, oy) delante del rostro. */
    rig.burst = function burst(pos, vel, n, ox, oy) {
      const R = 80;
      for (let i = 0; i < n; i += 1) {
        const ix = i * 3;
        const dx = pos[ix] - ox;
        const dy = pos[ix + 1] - oy;
        const dz = pos[ix + 2] - 14;
        const d = Math.hypot(dx, dy, dz) + 1;
        const near = Math.max(0, 1 - d / R);
        const f = (near * near * 3.4 + 0.9) * (0.7 + Math.random() * 0.6);
        vel[ix] += (dx / d) * f + (Math.random() - 0.5) * 1.1;
        vel[ix + 1] += (dy / d) * f + (Math.random() - 0.5) * 1.1;
        vel[ix + 2] += (dz / d) * f + (Math.random() - 0.5) * 2.2;
      }
    };

    return rig;
  }

  root.VirginiaFace = { generate, createRig, depth, inside, version: '1.1.0' };
})(typeof window !== 'undefined' ? window : globalThis);
