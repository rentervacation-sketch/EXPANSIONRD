(() => {
  'use strict';

  const EFFECTS = [
    'Neural Field Density','Quantum Vortex','Shockwave Impulse','Spiral Galaxy Spin',
    'Inverse Gravity Push','3D Perlin Turbulence','Tactile Magnet Pull','Click Nova Explosion',
    'Vibrating Strings','Lorenz Chaotic Attractor','Crystal Lattice Solid','Viscous Hydro-Fluid',
    'Acoustic Harmonic Wave','Solar Flare Ejection','Orbital Ring Swarm','Black Hole Singularity',
    'DNA Double Helix','Quantum Superposition','Atomic Electron Cloud','Thermal Brownian Motion',
    'Plasma Arc Discharge','Matrix Rain Stream','Cybernetic Grid Warp','Nebula Cloud Drift','Gravitational Lensing',
    'Fluid Vortex Ring','Superconductive Levitation','Photon Emission Burst','Tachyon Acceleration','Pulsar Jet Stream',
    'String Theory Calabi','Magnetic Ferrofluid','Subatomic Quark Chaos','Hyperdimensional Hypercube','Dark Matter Filaments',
    'Cosmic Ray Shower','Seismic Fault Ripple','Ionic Drift Plasma','Zero-Point Energy Pulse','Kinetic Avalanche','Rostro Virgin.IA'
  ];
  const FACE = 40;
  const PALETTES = [
    {name:'Neural Emerald',colors:['#34d399','#10b981','#06b6d4','#a7f3d0']},
    {name:'Cyberpunk Neon',colors:['#06b6d4','#3b82f6','#ec4899','#f43f5e']},
    {name:'Deep Space Blue',colors:['#1d4ed8','#3b82f6','#60a5fa','#93c5fd']},
    {name:'Sunset Gold Flare',colors:['#f59e0b','#ef4444','#fbbf24','#dc2626']},
    {name:'Tokyo Night',colors:['#7c3aed','#c084fc','#38bdf8','#818cf8']},
    {name:'Bio-Luminescence',colors:['#10b981','#059669','#34d399','#6ee7b7']},
    {name:'Prism Acid Green',colors:['#84cc16','#22c55e','#10b981','#a3e635']},
    {name:'Monochrome Luxe',colors:['#f8fafc','#cbd5e1','#64748b','#334155']},
    {name:"Synthwave '84",colors:['#f43f5e','#d946ef','#8b5cf6','#06b6d4']},
    {name:'Matrix Green Code',colors:['#15803d','#22c55e','#4ade80','#86efac']},
    {name:'Aurora Borealis',colors:['#2dd4bf','#34d399','#818cf8','#c084fc']},
    {name:'Cosmic Vaporwave',colors:['#f472b6','#38bdf8','#a78bfa','#f43f5e']},
    {name:'Infra-Red Thermal',colors:['#ef4444','#f97316','#eab308','#b91c1c']},
    {name:'Plasma Violet',colors:['#a855f7','#6366f1','#d946ef','#c084fc']},
    {name:'Solarized Amber',colors:['#d97706','#f59e0b','#fbbf24','#78350f']},
    {name:'Glacier Ice',colors:['#0ea5e9','#38bdf8','#7dd3fc','#bae6fd']},
    {name:'Volcanic Lava',colors:['#b91c1c','#dc2626','#f97316','#450a0a']},
    {name:'Quantum Opal',colors:['#f472b6','#fb7185','#38bdf8','#a7f3d0']},
    {name:'Electric Ultraviolet',colors:['#9333ea','#7e22ce','#c084fc','#e879f9']},
    {name:'Golden Horizon',colors:['#eab308','#ca8a04','#fef08a','#a16207']}
  ];
  const PARAMS = [
    {key:'pSize',label:'Tamaño partícula',min:.5,max:15,step:.1,value:2.5,digits:1},
    {key:'pCount',label:'Cantidad',min:500,max:15000,step:500,value:(innerWidth<700?4200:6500),digits:0},
    {key:'speed',label:'Velocidad de flujo',min:0,max:5,step:.1,value:1,digits:1},
    {key:'damping',label:'Amortiguamiento / fricción',min:.8,max:.99,step:.01,value:.92,digits:2},
    {key:'mass',label:'Masa / inercia',min:.1,max:5,step:.1,value:1,digits:1},
    {key:'attrRadius',label:'Radio de atracción',min:10,max:200,step:5,value:60,digits:0},
    {key:'forceIntensity',label:'Intensidad de fuerza',min:-5,max:5,step:.1,value:1.5,digits:1},
    {key:'gravity',label:'Gravedad local',min:-2,max:2,step:.1,value:0,digits:1},
    {key:'noiseFreq',label:'Frecuencia de ruido',min:.005,max:.3,step:.005,value:.05,digits:3},
    {key:'jitter',label:'Agitación / caos',min:0,max:2,step:.05,value:.1,digits:2},
    {key:'audioSens',label:'Sensibilidad de audio',min:0,max:4,step:.1,value:1,digits:1,audio:true},
    {key:'opacity',label:'Opacidad',min:.1,max:1,step:.05,value:.85,digits:2},
    {key:'radius',label:'Radio / escala',min:20,max:200,step:5,value:70,digits:0},
    {key:'spin',label:'Rotación / spin',min:-3,max:3,step:.1,value:.5,digits:1},
    {key:'elasticity',label:'Elasticidad / deformación',min:0,max:.5,step:.01,value:.08,digits:2}
  ];
  const plans = [
    {level:'LEVEL 01',tag:'MANUAL DISPATCH',name:'STARTER',description:'Detección e inteligencia de inventario para envíos manuales de alta precisión.',monthly:'200',annual:'160',audience:'Para asesores independientes',features:['Parsing semántico de fichas técnicas','Matcheo inteligente de demanda','Alertas de Oportunidades & Voids','Envío manual (WhatsApp / PDF)','Inventario propio (hasta 50 prop)','Marca personal (White-Label)']},
    {level:'LEVEL 02',tag:'AUTO DISPATCHER',name:'ADVANCED',description:'Despacho automático inmediato con conexión directa a WhatsApp API.',monthly:'500',annual:'400',audience:'Para equipos de ventas boutique',features:['Todo lo del plan Starter +','Conexión WhatsApp API (Evolution Engine)','Envío 100% automático de opciones','Calificación & filtrado inicial de leads','Seguimientos automáticos (24h / 72h / 7d)','Inventario propio (hasta 200 prop)']},
    {level:'LEVEL 03',tag:'FULL EXECUTIVE',name:'PRO',description:'Asesor conversacional avanzado, agendamiento y recomendación autónoma.',monthly:'1,000',annual:'800',audience:'Costo por licencia / usuario',features:['Todo lo del plan Advanced +','Agente Conversacional Avanzado LLM','Sugerencia dinámica & Venta cruzada','Agendamiento autónomo de Citas','Pipeline de seguimiento por comportamiento','Inventario Propio ILIMITADO']},
    {level:'LEVEL 04',tag:'ENTERPRISE & SUITE',name:'UNLIMITED',description:'Multiagente, Atlas de Mercado Real-Time y acceso a la red exclusiva de brokers.',monthly:'',annual:'',audience:'Esquema flexible / Opción por comisión',features:['Todo lo del plan Pro +','Multiagentes CrewAI (Hunter, Outreach, Analyst)','Atlas de Mercado Real-Time (Tendencias)','Red de +2,000 Brokers Riviera Maya','Envío de Campañas Selectivas & Automáticas','Radar de Oportunidades Únicas en Tiempo Real','Acceso exclusivo al Club VIRGIN.IA','Motor SINAPPCO (Análisis GIS + Grilla H3)']}
  ];
  let canvas = document.getElementById('particle-canvas');
  const controls = document.getElementById('neural-controls');
  const toggle = document.querySelector('.control-toggle');
  const loading = document.getElementById('engine-loading');
  const errorBox = document.getElementById('engine-error');
  const errorMessage = document.getElementById('engine-error-message');
  const backdrop = document.getElementById('modal-backdrop');
  const dialog = document.getElementById('modal-dialog');
  const modalContent = document.getElementById('modal-content');
  let annual = false;
  let activeModal = null;
  let savedFocus = null;
  let engine = null;
  let loadTimeout;
  let fallbackRequested = false;
  let fallbackMode = false;
  document.documentElement.dataset.virginiaHomeEngine = 'active';

  function renderPlans() {
    const grid = document.getElementById('plan-grid');
    if (!grid) return;
    grid.innerHTML = plans.map((plan,index) => {
      const price = index === 3 ? '<strong>COTIZACIÓN<br>A MEDIDA</strong>' : '<small>'+(index===2?'DESDE ':'')+'USD $</small><strong>'+(annual?plan.annual:plan.monthly)+'</strong><small>/mes</small>';
      const features = plan.features.map((feature,n) => '<li><span aria-hidden="true">'+(n===0&&index>0?'＋':'✓')+'</span>'+feature+'</li>').join('');
      const label = index===3?'SOLICITAR COTIZACIÓN':index===2?'ACTIVAR PLAN PRO':'SELECCIONAR '+plan.name;
      return '<article class="plan-card '+(index===2?'featured':'')+'"><div class="plan-top"><span>'+plan.level+'</span><span>'+plan.tag+'</span></div>'+(index===2?'<div class="popular">MÁS POPULAR</div>':'')+'<h3>'+plan.name+'</h3><p class="plan-description">'+plan.description+'</p><div class="plan-price">'+price+'<span>'+plan.audience+'</span></div><ul>'+features+'</ul><a class="plan-cta '+(index===2?'primary':'')+'" href="/sign-up">'+label+' <span aria-hidden="true">→</span></a></article>';
    }).join('');
  }
  function updateNav(view) {
    document.querySelectorAll('.nav button').forEach(button => button.classList.toggle('active',button.dataset.view===(view||'home')));
  }
  function openModal(view) {
    if (view === 'home') { closeModal(); return; }
    savedFocus = document.activeElement;
    activeModal = view;
    const pricing = view === 'pricing';
    dialog.classList.toggle('pricing-dialog',pricing);
    if (pricing) {
      modalContent.innerHTML = '<div class="modal-intro"><span class="eyebrow">02 / LICENCIAS Y PLANES DE DESPLIEGUE</span><h2 id="modal-title">Una inteligencia.<br><em>La escala de tu operación.</em></h2><p>Selecciona la infraestructura de inteligencia inmobiliaria que mejor se adapte a la escala de tu operación.</p></div><div class="billing" role="group" aria-label="Frecuencia de facturación"><button type="button" data-billing="monthly" class="active" aria-pressed="true">Mensual</button><button type="button" data-billing="annual" aria-pressed="false">Anual <span>−20%</span></button></div><div class="plan-grid" id="plan-grid"></div>';
      renderPlans();
    } else if (view === 'modules') {
      modalContent.innerHTML = '<div class="info-content"><span class="eyebrow">VIRGIN.IA / CAPACIDADES</span><h2 id="modal-title">De la señal a la operación.</h2><p>Matched &amp; Speed conecta demanda e inventario. La IA conversacional acompaña cada lead. Inteligencia GIS descubre zonas con potencial y los agentes coordinados automatizan prospección, análisis y seguimiento.</p><div class="info-modules"><div><span>01</span><b>Matched &amp; Speed</b></div><div><span>02</span><b>IA Conversacional</b></div><div><span>03</span><b>Inteligencia GIS</b></div><div><span>04</span><b>Multi-Agentes</b></div></div></div>';
    } else {
      modalContent.innerHTML = '<div class="info-content"><span class="eyebrow">EXPANSION + R&amp;D / CONTACTO</span><h2 id="modal-title">Hablemos de tu operación.</h2><p>Descubre cómo VIRGIN.IA puede solucionar los desafíos clave de tu industria. Solicita una demostración para explorar datos, automatización y oportunidades de mercado con nuestro equipo.</p><a class="button button-primary" href="/sign-up">Solicitar una demostración <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a></div>';
    }
    backdrop.hidden = false;
    updateNav(view);
    document.getElementById('close-modal').focus();
  }
  function closeModal() {
    if (backdrop.hidden) return;
    activeModal = null;
    backdrop.hidden = true;
    dialog.classList.remove('pricing-dialog');
    updateNav('home');
    if (savedFocus && savedFocus.isConnected) savedFocus.focus();
  }
  document.querySelectorAll('.nav button').forEach(button => button.addEventListener('click',() => openModal(button.dataset.view)));
  document.querySelectorAll('[data-open]').forEach(button => button.addEventListener('click',() => openModal(button.dataset.open)));
  document.querySelector('.brand').addEventListener('click',event => { event.preventDefault(); closeModal(); });
  document.getElementById('close-modal').addEventListener('click',closeModal);
  backdrop.addEventListener('pointerdown',event => { if (event.target===backdrop) closeModal(); });
  backdrop.addEventListener('click',event => {
    const billing = event.target.closest('[data-billing]');
    if (!billing) return;
    annual = billing.dataset.billing === 'annual';
    backdrop.querySelectorAll('[data-billing]').forEach(button => {
      const active = button===billing;
      button.classList.toggle('active',active);
      button.setAttribute('aria-pressed',String(active));
    });
    renderPlans();
  });

  function panelMarkup() {
    controls.innerHTML = '<div class="control-heading"><div><span>VIRGIN.IA / ENGINE</span><h2>Panel Neural</h2></div><button type="button" id="close-controls" aria-label="Cerrar panel">×</button></div><div class="panel-tabs" role="tablist" aria-label="Ajustes del motor"><button type="button" class="active" data-tab="elements" role="tab" aria-selected="true">CAPAS</button><button type="button" data-tab="effects" role="tab" aria-selected="false">40 EFECTOS</button><button type="button" data-tab="colors" role="tab" aria-selected="false">20 PALETAS</button></div><div class="panel-body"><section class="panel-view" data-view="elements" role="tabpanel"><div class="layer-topline"><span>Capas activas <b id="element-count">1/4</b></span><button class="add-element" id="add-element" type="button">＋ Añadir Elemento</button></div><div class="layer-tabs" id="layer-tabs" aria-label="Seleccionar capa"></div><div id="parameter-controls"></div></section><section class="panel-view" data-view="effects" role="tabpanel" hidden><p class="section-kicker">COMPORTAMIENTO DE LA CAPA SELECCIONADA</p><div class="effect-grid" id="effect-grid"></div></section><section class="panel-view" data-view="colors" role="tabpanel" hidden><p class="section-kicker">ESQUEMA CROMÁTICO DE LA CAPA SELECCIONADA</p><div class="palette-grid" id="palette-grid"></div></section></div><div class="panel-footer"><button class="shockwave-button" id="shockwave" type="button">Emitir onda en el centro del campo</button></div>';
    document.getElementById('close-controls').addEventListener('click',closePanel);
    controls.querySelectorAll('[data-tab]').forEach(button => button.addEventListener('click',() => selectPanelTab(button.dataset.tab)));
    document.getElementById('add-element').addEventListener('click',addElement);
    document.getElementById('shockwave').addEventListener('click',() => engine?.shockwave(innerWidth/2,innerHeight/2));
    renderEffectOptions();
    renderPaletteOptions();
  }
  function openPanel() { controls.hidden=false; toggle.classList.add('selected');toggle.setAttribute('aria-expanded','true'); }
  function closePanel() { controls.hidden=true;toggle.classList.remove('selected');toggle.setAttribute('aria-expanded','false'); }
  toggle.addEventListener('click',() => controls.hidden ? openPanel() : closePanel());
  function selectPanelTab(name) {
    controls.querySelectorAll('[data-tab]').forEach(button => {
      const active = button.dataset.tab===name;
      button.classList.toggle('active',active);
      button.setAttribute('aria-selected',String(active));
    });
    controls.querySelectorAll('.panel-view').forEach(view => { view.hidden=view.dataset.view!==name; });
    if (name==='elements') renderLayerControls();
  }
  function renderEffectOptions() {
    const grid = document.getElementById('effect-grid');
    grid.innerHTML = EFFECTS.map((effect,index) => '<button class="effect-option" type="button" data-effect="'+index+'" aria-pressed="false"><b>'+String(index+1).padStart(2,'0')+'</b><span>'+effect+'</span></button>').join('');
    grid.addEventListener('click',event => {
      const option=event.target.closest('[data-effect]');
      if (!option) return;
      const layer=activeLayer();
      layer.effectIndex=Number(option.dataset.effect);
      renderLayerControls();
      updateOptionStates();
    });
  }
  function renderPaletteOptions() {
    const grid=document.getElementById('palette-grid');
    grid.innerHTML=PALETTES.map((palette,index) => '<button class="palette-option" type="button" data-palette="'+index+'" aria-pressed="false"><span>'+String(index+1).padStart(2,'0')+' · '+palette.name+'</span><i class="swatches">'+palette.colors.map(color=>'<i style="background:'+color+'"></i>').join('')+'</i></button>').join('');
    grid.addEventListener('click',event => {
      const option=event.target.closest('[data-palette]');
      if (!option) return;
      const layer=activeLayer();
      layer.paletteIndex=Number(option.dataset.palette);
      layer.recolor();
      updateOptionStates();
    });
  }
  function updateOptionStates() {
    const layer=activeLayer();
    controls.querySelectorAll('[data-effect]').forEach(button => button.setAttribute('aria-pressed',String(Number(button.dataset.effect)===layer.effectIndex)));
    controls.querySelectorAll('[data-palette]').forEach(button => button.setAttribute('aria-pressed',String(Number(button.dataset.palette)===layer.paletteIndex)));
  }
  function activeLayer() { return engine?.elements[engine.activeIndex]; }
  function renderLayerControls() {
    if (!engine) return;
    const active=activeLayer();
    document.getElementById('element-count').textContent=engine.elements.length+'/4';
    document.getElementById('add-element').disabled=engine.elements.length>=4;
    document.getElementById('add-element').title=engine.elements.length>=4?'Límite de 4 capas simultáneas para mantener fluidez':'';
    document.getElementById('layer-tabs').innerHTML=engine.elements.map((layer,index) => '<button type="button" class="layer-tab '+(index===engine.activeIndex?'active':'')+'" data-layer="'+index+'" aria-pressed="'+(index===engine.activeIndex)+'" style="--layer-color:'+PALETTES[layer.paletteIndex].colors[0]+'"><i></i>'+layer.name+'</button>').join('');
    document.getElementById('layer-tabs').querySelectorAll('[data-layer]').forEach(button => button.addEventListener('click',() => {
      engine.activeIndex=Number(button.dataset.layer);
      renderLayerControls();updateOptionStates();
    }));
    const p=active.params;
    const sliders=PARAMS.map(param => '<div class="range-card '+(param.audio?'audio-setting':'')+'"><label for="param-'+param.key+'"><span>'+param.label+'</span><output id="value-'+param.key+'">'+Number(p[param.key]).toFixed(param.digits)+'</output></label><input id="param-'+param.key+'" type="range" min="'+param.min+'" max="'+param.max+'" step="'+param.step+'" value="'+p[param.key]+'" aria-label="'+param.label+'"></div>').join('');
    document.getElementById('parameter-controls').innerHTML='<div class="layer-title"><span>'+active.name+'</span><small>'+EFFECTS[active.effectIndex]+'</small></div><div class="layer-actions"><button type="button" data-cursor="attract" class="'+(active.cursorMode==='attract'?'active':'')+'" aria-pressed="'+(active.cursorMode==='attract')+'">Atracción cursor</button><button type="button" data-cursor="repel" class="'+(active.cursorMode==='repel'?'active':'')+'" aria-pressed="'+(active.cursorMode==='repel')+'">Repulsión cursor</button><button type="button" id="remove-layer" '+(engine.elements.length===1?'disabled title="Debe quedar al menos una capa"':'')+'>Eliminar capa</button></div><div class="parameter-grid">'+sliders+'</div><p class="parameter-caption">Sensibilidad de audio se conserva como ajuste compatible futuro; no activa micrófono ni audio. Hasta cuatro capas simultáneas.</p>';
    document.querySelectorAll('#parameter-controls input[type=range]').forEach(input => input.addEventListener('input',() => {
      const spec=PARAMS.find(item=>item.key===input.id.slice(6));
      const next=Number(input.value);
      active.params[spec.key]=next;
      document.getElementById('value-'+spec.key).value=next.toFixed(spec.digits);
      if(spec.key==='pCount') active.rebuild(next);
      else active.applyParameters();
    }));
    document.querySelectorAll('[data-cursor]').forEach(button => button.addEventListener('click',() => {
      active.cursorMode=button.dataset.cursor;
      renderLayerControls();
    }));
    document.getElementById('remove-layer').addEventListener('click',() => removeActiveLayer());
    updateOptionStates();
  }
  function addElement() {
    if (!engine || engine.elements.length>=4) return;
    const element=engine.addElement();
    engine.activeIndex=engine.elements.indexOf(element);
    renderLayerControls();
    updateOptionStates();
  }
  function removeActiveLayer() {
    if (!engine || engine.elements.length<=1) return;
    engine.removeElement(engine.activeIndex);
    renderLayerControls();
    updateOptionStates();
  }
  panelMarkup();

  document.addEventListener('keydown',event => {
    if (event.key==='Escape') {
      if (!backdrop.hidden) closeModal();
      else if (!controls.hidden) closePanel();
    }
    if (event.key==='Tab' && !backdrop.hidden) {
      const focusables=dialog.querySelectorAll('button:not(:disabled),a[href],input:not(:disabled)');
      if (!focusables.length) return;
      const first=focusables[0],last=focusables[focusables.length-1];
      if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}
      else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
    }
  });

  const reducedMotion=matchMedia('(prefers-reduced-motion: reduce)');
  function loadThree() {
    loading.hidden=false;errorBox.hidden=true;
    if (window.THREE) { startEngine(window.THREE); return; }
    const script=document.createElement('script');
    script.src='https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js';
    script.async=true;
    script.onload=()=>{if(fallbackMode)return;window.THREE?startEngine(window.THREE):requestCanvasFallback();};
    script.onerror=()=>requestCanvasFallback();
    document.head.appendChild(script);
    loadTimeout=setTimeout(()=>{if(!window.THREE)requestCanvasFallback();},12000);
  }
  function failEngine(message) {
    clearTimeout(loadTimeout);loading.hidden=true;errorMessage.textContent=message;errorBox.hidden=false;
  }
  function requestCanvasFallback() {
    if(fallbackRequested||(fallbackMode&&engine?.isCanvasFallback))return;
    clearTimeout(loadTimeout);
    fallbackRequested=true;
    fallbackMode=true;
    window.__VIRGINIA_HOME_FALLBACK_PENDING__=true;
    const replacement=canvas.cloneNode(false);
    canvas.replaceWith(replacement);
    canvas=replacement;
    loading.hidden=false;
    loading.innerHTML='<span></span> INICIANDO CAMPO NEURAL 2D';
    if(typeof window.__VIRGINIA_HOME_FALLBACK_START__==='function')window.__VIRGINIA_HOME_FALLBACK_START__();
  }
  window.__VIRGINIA_HOME_FALLBACK_START__=function startCanvasFallback() {
    const bridge=window.VirginiaCanvasFallback;
    if(!fallbackRequested||!bridge||engine?.isCanvasFallback)return;
    try {
      if(engine){engine.destroy();engine=null;}
      const renderer=bridge.create({canvas,palettes:PALETTES,effects:EFFECTS,reducedMotion:reducedMotion.matches});
      const elements=[];
      let activeIndex=0;
      const api={
        elements,isCanvasFallback:true,
        get activeIndex(){return activeIndex;},set activeIndex(value){activeIndex=value;},
        addElement(){
          const id=elements.length?Math.max(...elements.map(element=>element.id))+1:1;
          const element=renderer.createElement(id,'Elemento '+id,paramsDefault());
          elements.push(element);return element;
        },
        removeElement(index){
          const element=elements[index];if(!element)return;
          element.destroy();elements.splice(index,1);activeIndex=Math.max(0,Math.min(activeIndex,elements.length-1));
        },
        shockwave(x,y){renderer.shockwave(x,y);},
        destroy(){renderer.destroy();elements.forEach(element=>element.destroy());elements.length=0;},
        camera:renderer.camera
      };
      engine=api;
      api.addElement();
      renderer.start(()=>elements);
      fallbackRequested=false;
      window.__VIRGINIA_HOME_FALLBACK_PENDING__=false;
      loading.hidden=true;errorBox.hidden=true;
      renderLayerControls();updateOptionStates();
    } catch(error) {
      failEngine('No fue posible iniciar el campo de partículas 2D en este dispositivo.');
    }
  };
  document.getElementById('retry-engine').addEventListener('click',()=>{
    clearTimeout(loadTimeout);
    if(engine){engine.destroy();engine=null;}
    const replacement=canvas.cloneNode(false);
    canvas.replaceWith(replacement);
    canvas=replacement;
    fallbackRequested=false;
    fallbackMode=false;
    window.__VIRGINIA_HOME_FALLBACK_PENDING__=false;
    loadThree();
  });
  const paramsDefault=()=>Object.fromEntries(PARAMS.map(({key,value})=>[key,value]));

  class NeuralElement {
    constructor(THREE,id,name,texture) {
      this.THREE=THREE;this.id=id;this.name=name;this.texture=texture;
      this.params=paramsDefault();this.paletteIndex=0;this.effectIndex=FACE;this.params.pSize=.85;this.cursorMode='repel';this.face=null;this.rig=null;this.lines=null;this.speaking=false;
      this.group=new THREE.Group();this.group.position.set(0,0,0);
      this.positions=null;this.originalPositions=null;this.velocities=null;this.colors=null;
      this.geometry=null;this.material=null;this.pointsMesh=null;this.initMesh();
    }
    initMesh(count=this.params.pCount) {
      this.destroyMesh();
      this.face=null;this.rig=null;
      const T=this.THREE,n=count;
      this.params.pCount=n;
      this.geometry=new T.BufferGeometry();
      this.positions=new Float32Array(n*3);this.originalPositions=new Float32Array(n*3);
      this.velocities=new Float32Array(n*3);this.colors=new Float32Array(n*3);
      const swatches=PALETTES[this.paletteIndex].colors;
      let cx=0,cy=0,cz=0;
      for(let i=0;i<n;i++){
        const theta=Math.random()*Math.PI*2,phi=Math.acos(2*Math.random()-1),r=Math.cbrt(Math.random())*this.params.radius;
        const ix=i*3,x=r*Math.sin(phi)*Math.cos(theta),y=r*Math.sin(phi)*Math.sin(theta),z=r*Math.cos(phi)*.5;
        this.positions[ix]=this.originalPositions[ix]=x;this.positions[ix+1]=this.originalPositions[ix+1]=y;this.positions[ix+2]=this.originalPositions[ix+2]=z;
        cx+=x;cy+=y;cz+=z;
        this.velocities[ix]=(Math.random()-.5)*.1;this.velocities[ix+1]=(Math.random()-.5)*.1;this.velocities[ix+2]=(Math.random()-.5)*.1;
        const color=new T.Color(swatches[Math.floor(Math.random()*swatches.length)]);
        this.colors[ix]=color.r;this.colors[ix+1]=color.g;this.colors[ix+2]=color.b;
      }
      cx/=n;cy/=n;cz/=n;
      for(let i=0;i<n;i++){const ix=i*3;this.positions[ix]-=cx;this.originalPositions[ix]-=cx;this.positions[ix+1]-=cy;this.originalPositions[ix+1]-=cy;this.positions[ix+2]-=cz;this.originalPositions[ix+2]-=cz;}
      this.geometry.setAttribute('position',new T.BufferAttribute(this.positions,3));
      this.geometry.setAttribute('color',new T.BufferAttribute(this.colors,3));
      this.material=new T.PointsMaterial({size:this.params.pSize,vertexColors:true,map:this.texture,transparent:true,opacity:this.params.opacity,blending:T.AdditiveBlending,depthWrite:false,sizeAttenuation:true});
      this.pointsMesh=new T.Points(this.geometry,this.material);
      this.pointsMesh.position.set(0,0,0);this.group.add(this.pointsMesh);
    }
    destroyMesh() {
      if(this.pointsMesh&&this.group)this.group.remove(this.pointsMesh);
      if(this.geometry)this.geometry.dispose();
      if(this.material)this.material.dispose();
      if(this.lines){this.group.remove(this.lines);this.lines.geometry.dispose();this.lines.material.dispose();this.lines=null;}
      this.pointsMesh=null;this.geometry=null;this.material=null;
    }
    rebuild(count) { this.initMesh(count); }
    recolor() {
      if(!this.colors)return;
      const colors=PALETTES[this.paletteIndex].colors;
      for(let i=0;i<this.params.pCount;i++){const c=new this.THREE.Color(colors[Math.floor(Math.random()*colors.length)]),ix=i*3;this.colors[ix]=c.r;this.colors[ix+1]=c.g;this.colors[ix+2]=c.b;}
      this.geometry.attributes.color.needsUpdate=true;
      if(this.face)this.tintFace();
    }
    ensureFace() {
      if(this.face||!window.VirginiaFace)return;
      const T=this.THREE,n=this.params.pCount;
      this.face=window.VirginiaFace.generate(Math.floor(n*.82));
      this.rig=window.VirginiaFace.createRig(this.face);this.rig.speaking=this.speaking;
      const E=this.face.edges.length/2;
      this._lp=new Float32Array(E*6);this._lc=new Float32Array(E*6);
      const g=new T.BufferGeometry();
      g.setAttribute('position',new T.BufferAttribute(this._lp,3));g.setAttribute('color',new T.BufferAttribute(this._lc,3));
      this.lines=new T.LineSegments(g,new T.LineBasicMaterial({vertexColors:true,transparent:true,opacity:.6,blending:T.AdditiveBlending,depthWrite:false}));
      this.lines.frustumCulled=false;this.group.add(this.lines);
      this.tintFace();
    }
    tintFace() {
      const F=this.face,c=this.colors,T=this.THREE;if(!F||!c)return;
      const base=new T.Color(PALETTES[this.paletteIndex].colors[0]);this._lineColor=[base.r*.32,base.g*.32,base.b*.32];
      for(let i=0;i<this.params.pCount;i++){
        const ix=i*3;
        if(i>=F.count){c[ix]*=.6;c[ix+1]*=.6;c[ix+2]*=.6;continue;}
        const sh=F.shade[i];
        if(F.kind[i]===1){c[ix]=1;c[ix+1]=1;c[ix+2]=1;}
        else if(F.kind[i]===2){c[ix]=Math.min(1,c[ix]*.3+.7);c[ix+1]=c[ix+1]*.3+.42*.7;c[ix+2]=c[ix+2]*.3+.6*.7;}
        else{const k=.5+.7*sh;c[ix]=Math.min(1,c[ix]*k);c[ix+1]=Math.min(1,c[ix+1]*k);c[ix+2]=Math.min(1,c[ix+2]*k);}
      }
      this.geometry.attributes.color.needsUpdate=true;
    }
    updateLines() {
      const F=this.face,pos=this.positions,lp=this._lp,lc=this._lc,E=F.edges,R=F.rest,S=this.rig.S,b=this._lineColor||[.1,.4,.3];
      for(let e=0;e<R.length;e++){
        const a=E[e*2]*3,d=E[e*2+1]*3,o=e*6;
        const ax=pos[a],ay=pos[a+1],az=pos[a+2],bx=pos[d],by=pos[d+1],bz=pos[d+2];
        lp[o]=ax;lp[o+1]=ay;lp[o+2]=az;lp[o+3]=bx;lp[o+4]=by;lp[o+5]=bz;
        let w=1.6-Math.hypot(ax-bx,ay-by,az-bz)/(R[e]*S)*.6;w=w<0?0:w>1?1:w;w*=.35+.65*Math.min(1,(F.shade[a/3]+F.shade[d/3])*.5);
        const r=b[0]*w,g=b[1]*w,bl=b[2]*w;
        lc[o]=lc[o+3]=r;lc[o+1]=lc[o+4]=g;lc[o+2]=lc[o+5]=bl;
      }
      this.lines.geometry.attributes.position.needsUpdate=true;this.lines.geometry.attributes.color.needsUpdate=true;
    }
    burst(x,y) {
      if(this.effectIndex!==FACE||!this.rig||!this.positions)return;
      this.rig.burst(this.positions,this.velocities,this.params.pCount,x-this.group.position.x,y);
    }
    applyParameters() {
      if(this.material){this.material.size=this.params.pSize;this.material.opacity=this.params.opacity;this.material.needsUpdate=true;}
    }
    formTarget(i,time) {
      const p=this.params,orig=this.originalPositions,idx=i*3;
      const ox=orig[idx],oy=orig[idx+1],oz=orig[idx+2],r=p.radius/70;
      let tx=ox*r,ty=oy*r,tz=oz*r;
      const phase=i*.017,angle=Math.atan2(oy,ox),rad=Math.hypot(ox,oy)*r;
      switch(this.effectIndex){
        case 10: {const spacing=(i%15-7)*2.5;tx=spacing;ty=(Math.floor(i/15)%15-7)*2.5;tz=(Math.floor(i/225)%15-7)*2.5;break;}
        case 14: {const ring=i%4,theta=phase+ring*Math.PI/2;tx=Math.cos(theta)*p.radius*(.55+ring*.12);ty=Math.sin(theta)*p.radius*(.55+ring*.12);tz=(Math.floor(i/4)%36-18)*.9;break;}
        case 16: {const t=i/Math.max(1,p.pCount-1)*Math.PI*16;tx=Math.cos(t)*p.radius*.48;ty=Math.sin(t)*p.radius*.48;tz=(i/p.pCount-.5)*p.radius*1.3;break;}
        case 17: {const mix=(i%2)?1:-1;tx=ox*r*mix*.75;ty=oy*r;tz=oz*r;break;}
        case 18: {const theta=phase*4;tx=Math.cos(theta)*p.radius*.55;ty=Math.sin(theta)*p.radius*.55;tz=Math.sin(phase*1.7)*p.radius*.4;break;}
        case 21: {const column=i%90;tx=(column-45)*1.1;ty=((i*7)%100-50)*1.3;tz=Math.sin(time*1.5+i*.08)*12;break;}
        case 22: {const cell=i%8;tx=(cell-3.5)*p.radius*.22;ty=oy*r;tz=(Math.floor(i/8)%8-3.5)*p.radius*.22;break;}
        case 30: {const u=(i%128)/128*Math.PI*2,v=Math.floor(i/128)/Math.max(1,p.pCount/128)*Math.PI;const q=2+Math.cos(v);tx=(q*Math.cos(u))*p.radius*.29;ty=(q*Math.sin(u))*p.radius*.29;tz=Math.sin(v)*p.radius*.29;break;}
        case 33: {const corner=i%8;tx=((corner&1)?1:-1)*p.radius*.55;ty=((corner&2)?1:-1)*p.radius*.55;tz=((corner&4)?1:-1)*p.radius*.55;break;}
        case 35: {const ray=i%12,theta=ray*Math.PI/6;const distance=((i*17)%100)/100*p.radius;tx=Math.cos(theta)*distance;ty=Math.sin(theta)*distance;tz=((i*11)%100-50)*.55;break;}
        case 36: {tx=ox*r;ty=oy*r+Math.sin(rad*.07-time*2)*p.elasticity*30;tz=oz*r;break;}
        default:
          if(this.effectIndex===8){tx=ox*r;ty=Math.sin(angle*4+time*2)*p.radius*.23;tz=oz*r;}
          else if(this.effectIndex===15){const swirl=time*.4+angle;tx=Math.cos(swirl)*Math.max(3,rad*.32);ty=Math.sin(swirl)*Math.max(3,rad*.32);tz=oz*r*.35;}
          else if(this.effectIndex===19){tx=ox*r+Math.sin(time*3+i)*p.jitter*4;ty=oy*r+Math.cos(time*2+i*.3)*p.jitter*4;}
          else if(this.effectIndex===23){tx=ox*r+Math.sin(time+oy*.04)*10;ty=oy*r+Math.cos(time+ox*.04)*8;}
          else if(this.effectIndex===24){const lens=1+24/(rad*rad+100);tx=ox*r*lens;ty=oy*r*lens;}
          else if(this.effectIndex===26){tz=oz*r+Math.sin(time*2+phase)*p.elasticity*40;}
          else if(this.effectIndex===29){tx=ox*r+Math.cos(angle)*Math.sin(time*2+phase)*p.elasticity*70;ty=oy*r+Math.sin(angle)*Math.sin(time*2+phase)*p.elasticity*70;}
          else if(this.effectIndex===34){const strand=Math.sin(angle*5+rad*.05+time);tx=ox*r+strand*11;ty=oy*r+Math.cos(angle*4+time)*10;}
          break;
      }
      return [tx,ty,tz];
    }
    update(time,mouse,waves,dt) {
      if(!this.geometry)return;
      const p=this.params,pos=this.positions,vel=this.velocities,n=p.pCount;
      const effect=this.effectIndex,isFace=effect===FACE&&!!window.VirginiaFace,mouseX=mouse.x-this.group.position.x;
      if(isFace){this.ensureFace();this.lines.visible=true;this.rig.speaking=this.speaking;this.rig.prepare(time,dt,mouseX,mouse.y,p.radius);}
      else if(this.lines)this.lines.visible=false;
      for(let i=0;i<n;i++){
        const ix=i*3,px=pos[ix],py=pos[ix+1],pz=pos[ix+2],dx=mouseX-px,dy=mouse.y-py,dist=Math.hypot(dx,dy);
        const target=isFace?this.rig.target(i,time):this.formTarget(i,time),mass=p.mass;
        let ax=(target[0]-px)*(.0008+p.elasticity*.002)/mass;
        let ay=(target[1]-py)*(.0008+p.elasticity*.002)/mass;
        let az=(target[2]-pz)*(.0008+p.elasticity*.002)/mass;
        const phase=i*p.noiseFreq*11+time*(.5+p.speed*.45),freq=p.noiseFreq;
        // Distinct field families keep all forty reference choices physically legible.
        if(effect===1||effect===3||effect===25||effect===31){const radius=effect===25?p.radius*.8:p.attrRadius;if(dist<radius&&dist>.1){const f=(1-dist/radius)*p.forceIntensity*.12;ax+=-dy/dist*f;ay+=dx/dist*f;}}
        if(effect===4||effect===15||effect===24){if(dist<p.attrRadius&&dist>.1){const direction=effect===4?-1:1,f=(1-dist/p.attrRadius)*Math.abs(p.forceIntensity)*.18;ax+=dx/dist*f*direction;ay+=dy/dist*f*direction;}}
        if(effect===6||effect===16||effect===18||effect===26||effect===32||effect===37){if(dist<p.attrRadius&&dist>.1){const f=(1-dist/p.attrRadius)*p.forceIntensity*.13;ax+=dx/dist*f;ay+=dy/dist*f;}}
        if(effect===2||effect===7||effect===27||effect===38){for(const wave of waves){const edge=Math.abs(distTo(px,py,wave.x,wave.y)-wave.radius);if(edge<12){const d=Math.hypot(px-wave.x,py-wave.y)||.01,impulse=(1-edge/12)*.025*p.forceIntensity;ax+=(px-wave.x)/d*impulse;ay+=(py-wave.y)/d*impulse;}}}
        if(effect===5||effect===9||effect===19||effect===32){ax+=Math.sin(py*freq+time*1.6+phase)*p.jitter*.014;ay+=Math.cos(px*freq-time+phase)*p.jitter*.014;az+=Math.sin((px+py)*freq+time)*p.jitter*.009;}
        if(effect===8||effect===12||effect===13||effect===20||effect===29||effect===37){ay+=Math.sin(time*(1+effect*.04)+px*freq*8+phase)*(.008+p.elasticity*.055);az+=Math.cos(time+py*freq*7)*p.elasticity*.025;}
        if(effect===11||effect===23||effect===25||effect===31){ax+=-py*.00045;ay+=px*.00045;az+=Math.sin(phase+time)*.004;}
        if(effect===13||effect===27||effect===28||effect===29||effect===35||effect===38){const burst=Math.max(0,Math.sin(time*2+phase));ax+=Math.cos(Math.atan2(py,px))*burst*.012*p.forceIntensity;ay+=Math.sin(Math.atan2(py,px))*burst*.012*p.forceIntensity;}
        if(effect===21||effect===22||effect===30||effect===33){const stream=Math.sin(time*1.3+phase);ay+=stream*.012;az+=Math.cos(time+phase)*.009;ax+=Math.sin(py*freq*3+time)*.006;}
        if(effect===10||effect===14||effect===16||effect===17||effect===18||effect===22||effect===30||effect===33){ax+=(target[0]-px)*.0025;ay+=(target[1]-py)*.0025;az+=(target[2]-pz)*.0025;}
        if(isFace){ax+=(target[0]-px)*.0042;ay+=(target[1]-py)*.0042;az+=(target[2]-pz)*.0042;}
        if(effect===36){ay+=Math.sin(Math.hypot(px,py)*.07-time*3)*.024*p.elasticity*4;}
        if(effect===39){const avalanche=Math.max(0,Math.sin(time*.8+phase));ay-=avalanche*.02;ax+=Math.sin(phase*3)*avalanche*.01;}
        if(effect===0||effect===3||effect===14||effect===17||effect===28||effect===34){ax+=-py*.00012*p.speed;ay+=px*.00012*p.speed;}
        const hoverR=isFace?Math.min(p.attrRadius,26):p.attrRadius;
        if(dist<hoverR&&dist>.2&&effect!==4&&effect!==15&&effect!==24&&effect!==1&&effect!==3&&effect!==25&&effect!==31){
          const direction=this.cursorMode==='repel'?-1:1,force=(1-dist/hoverR)*p.forceIntensity*.08;
          ax+=dx/dist*force*direction;ay+=dy/dist*force*direction;
        }
        ax+=(Math.random()-.5)*p.jitter*.002;ay+=(Math.random()-.5)*p.jitter*.002;
        ay-=p.gravity*.004;
        const damping=Math.pow(p.damping,dt*60);
        vel[ix]=(vel[ix]+ax*dt*60)*damping;vel[ix+1]=(vel[ix+1]+ay*dt*60)*damping;vel[ix+2]=(vel[ix+2]+az*dt*60)*damping;
        pos[ix]+=vel[ix]*p.speed*dt*60;pos[ix+1]+=vel[ix+1]*p.speed*dt*60;pos[ix+2]+=vel[ix+2]*p.speed*dt*60;
      }
      this.geometry.attributes.position.needsUpdate=true;
      if(isFace){this.pointsMesh.rotation.set(0,0,0);this.updateLines();}
      else{this.pointsMesh.rotation.y+=.005*p.spin*dt*60;this.pointsMesh.rotation.x+=.0015*p.spin*dt*60;}
    }
    destroy(){this.destroyMesh();this.group.clear();}
  }
  function distTo(x,y,a,b){return Math.hypot(x-a,y-b);}
  function createGlowTexture(THREE) {
    const c=document.createElement('canvas');c.width=c.height=64;
    const ctx=c.getContext('2d');if(ctx){const g=ctx.createRadialGradient(32,32,1,32,32,32);g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.18,'rgba(255,255,255,.92)');g.addColorStop(.45,'rgba(255,255,255,.28)');g.addColorStop(1,'rgba(255,255,255,0)');ctx.fillStyle=g;ctx.fillRect(0,0,64,64);}
    return new THREE.CanvasTexture(c);
  }
  function startEngine(THREE) {
    if(fallbackMode)return;
    if(engine){engine.destroy();engine=null;}
    loading.hidden=false;errorBox.hidden=true;
    try {
      const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(55,1,.1,1000);
      const view={yaw:0,pitch:0,distance:110,targetX:0,targetY:0};
      const lookTarget=new THREE.Vector3(),raycaster=new THREE.Raycaster();
      const interactionPlane=new THREE.Plane(new THREE.Vector3(0,0,1),0),ndc=new THREE.Vector2();
      const renderer=new THREE.WebGLRenderer({canvas,alpha:true,antialias:true,powerPreference:'high-performance',failIfMajorPerformanceCaveat:false});
      renderer.setClearColor(0x020617,0);
      const texture=createGlowTexture(THREE),elements=[];
      let activeIndex=0,frame=0,lastTime=performance.now(),elapsed=0,dead=false,autoRotate=false;
      const pointer={x:10000,y:10000},waves=[];
      const drag={button:null,pointerId:null,x:0,y:0,moved:false};
      let resizeObserver=null;
      const uiSelector='button,a,input,select,textarea,[role="dialog"],.controls,.camera-tools,.presets,.header,.modal-backdrop';
      function isUiTarget(target){return target instanceof Element&&!!target.closest(uiSelector);}
      function syncRotateButton(){document.querySelector('[data-camera="rotate"]')?.classList.toggle('active',autoRotate);}
      function updateCamera(){
        const cosPitch=Math.cos(view.pitch);
        camera.position.set(view.targetX+view.distance*Math.sin(view.yaw)*cosPitch,view.targetY+view.distance*Math.sin(view.pitch),view.distance*Math.cos(view.yaw)*cosPitch);
        camera.lookAt(view.targetX,view.targetY,0);camera.updateProjectionMatrix();camera.updateMatrixWorld(true);
      }
      const api={
        elements,get activeIndex(){return activeIndex},set activeIndex(value){activeIndex=value;},
        addElement(){
          const id=elements.length?Math.max(...elements.map(element=>element.id))+1:1;
          const layer=new NeuralElement(THREE,id,'Elemento '+id,texture);
          // Scene origin is intentionally exact; no cursor or camera-derived offset.
          layer.group.position.set(0,0,0);scene.add(layer.group);elements.push(layer);return layer;
        },
        removeElement(index){const layer=elements[index];if(!layer)return;scene.remove(layer.group);layer.destroy();elements.splice(index,1);activeIndex=Math.max(0,Math.min(activeIndex,elements.length-1));},
        shockwave(x,y){const pos=screenToWorld(x,y);waves.push({x:pos.x,y:pos.y,radius:1,age:0});for(const l of elements)l.burst(pos.x,pos.y);},
         speak(on){for(const l of elements)l.speaking=!!on;},
        destroy(){
          dead=true;cancelAnimationFrame(frame);removeEventListener('resize',resize);removeEventListener('pointermove',move);removeEventListener('pointerleave',leave);removeEventListener('pointerdown',pointerDown);removeEventListener('pointerup',pointerUp);removeEventListener('pointercancel',pointerUp);removeEventListener('contextmenu',contextMenu);removeEventListener('wheel',wheel);resizeObserver?.disconnect();
          elements.forEach(layer=>{scene.remove(layer.group);layer.destroy();});elements.length=0;
          texture.dispose();renderer.dispose();renderer.forceContextLoss();
        }
      };
      engine=api;
      api.addElement();
      function resize(){
        const rect=canvas.getBoundingClientRect(),width=Math.max(1,rect.width||canvas.clientWidth||innerWidth),height=Math.max(1,rect.height||canvas.clientHeight||innerHeight);
        renderer.setPixelRatio(Math.min(devicePixelRatio||1,1.35));renderer.setSize(width,height,false);
        camera.aspect=width/height;camera.updateProjectionMatrix();
        // En pantallas anchas el rostro se desplaza a la derecha para dejar libre el texto del hero.
        const aspect=width/height,faceX=(width>=1100&&aspect>1.1)?Math.min(62,aspect*28.6):0;
        for(const layer of elements)layer.group.position.x=faceX;
        updateCamera();
      }
      function screenToWorld(x,y){
        const box=canvas.getBoundingClientRect();
        if(!box.width||!box.height)return {x:view.targetX,y:view.targetY};
        ndc.set(((x-box.left)/box.width)*2-1,-((y-box.top)/box.height)*2+1);
        camera.updateMatrixWorld(true);raycaster.setFromCamera(ndc,camera);
        const point=raycaster.ray.intersectPlane(interactionPlane,new THREE.Vector3());
        return point?{x:point.x,y:point.y}:{x:view.targetX,y:view.targetY};
      }
      function move(event){
        if(drag.pointerId===event.pointerId){
          const dx=event.clientX-drag.x,dy=event.clientY-drag.y;
          if(drag.button===2){view.yaw-=dx*.007;view.pitch=THREE.MathUtils.clamp(view.pitch+dy*.007,-1.05,1.05);updateCamera();}
          else if(drag.button===1){
            camera.updateMatrixWorld(true);
            const worldPerPixel=2*view.distance*Math.tan(camera.fov*Math.PI/360)/Math.max(1,canvas.clientHeight||innerHeight);
            const right=new THREE.Vector3().setFromMatrixColumn(camera.matrixWorld,0),up=new THREE.Vector3().setFromMatrixColumn(camera.matrixWorld,1);
            const shift=new THREE.Vector3().addScaledVector(right,-dx*worldPerPixel).addScaledVector(up,dy*worldPerPixel);
            view.targetX+=shift.x;view.targetY+=shift.y;updateCamera();
          }
          if(Math.abs(dx)+Math.abs(dy)>2)drag.moved=true;
          drag.x=event.clientX;drag.y=event.clientY;
        }
        if(isUiTarget(event.target)){pointer.x=pointer.y=10000;return;}
        const p=screenToWorld(event.clientX,event.clientY);pointer.x=p.x;pointer.y=p.y;
      }
      function leave(){pointer.x=pointer.y=10000;}
      function pointerDown(event){
        if(isUiTarget(event.target))return;
        if(event.button===0){const p=screenToWorld(event.clientX,event.clientY);waves.push({x:p.x,y:p.y,radius:1,age:0});for(const l of elements)l.burst(p.x,p.y);return;}
        if(event.button!==1&&event.button!==2)return;
        event.preventDefault();drag.button=event.button;drag.pointerId=event.pointerId;drag.x=event.clientX;drag.y=event.clientY;drag.moved=false;
      }
      function pointerUp(event){
        if(drag.pointerId!==event.pointerId)return;
        if(!drag.moved&&drag.button===2){view.yaw+=Math.PI/8;updateCamera();}
        if(!drag.moved&&drag.button===1){autoRotate=!autoRotate;syncRotateButton();}
        drag.button=null;drag.pointerId=null;
      }
      function contextMenu(event){if(!isUiTarget(event.target))event.preventDefault();}
      function wheel(event){
        if(isUiTarget(event.target))return;
        event.preventDefault();
        const unit=event.deltaMode===1?16:event.deltaMode===2?innerHeight:1;
        view.distance=THREE.MathUtils.clamp(view.distance*Math.exp(event.deltaY*unit*.001),45,340);updateCamera();
      }
      function animate(now){
        if(dead)return;
        frame=requestAnimationFrame(animate);
        const dt=Math.min(.04,Math.max(.001,(now-lastTime)/1000));lastTime=now;
        if(!reducedMotion.matches){elapsed+=dt;}
        if(!reducedMotion.matches){
          for(const layer of elements)layer.update(elapsed,pointer,waves,dt);
          for(const wave of waves){wave.radius+=75*dt;wave.age+=dt;}
          for(let i=waves.length-1;i>=0;i--)if(waves[i].age>1.8)waves.splice(i,1);
          if(autoRotate){view.yaw+=dt*.12;updateCamera();}
        }
        renderer.render(scene,camera);
      }
      addEventListener('resize',resize);addEventListener('pointermove',move,{passive:true});addEventListener('pointerleave',leave);addEventListener('pointerdown',pointerDown);addEventListener('pointerup',pointerUp);addEventListener('pointercancel',pointerUp);addEventListener('contextmenu',contextMenu);addEventListener('wheel',wheel,{passive:false});
      if(typeof ResizeObserver!=='undefined'){resizeObserver=new ResizeObserver(resize);resizeObserver.observe(canvas);}
      resize();loading.hidden=true;errorBox.hidden=true;renderLayerControls();updateOptionStates();
      lastTime=performance.now();frame=requestAnimationFrame(animate);
      api.camera={
        zoom(delta){view.distance=THREE.MathUtils.clamp(view.distance+delta,45,340);updateCamera();},
        reset(){view.yaw=0;view.pitch=0;view.distance=110;view.targetX=0;view.targetY=0;autoRotate=false;syncRotateButton();updateCamera();},
        rotate(){autoRotate=!autoRotate;return autoRotate;}
      };
    } catch(error) {
      if(engine){engine.destroy();engine=null;}
      requestCanvasFallback();
    }
  }
  document.querySelectorAll('[data-camera]').forEach(button=>button.addEventListener('click',()=>{
    if(!engine?.camera)return;
    if(button.dataset.camera==='in')engine.camera.zoom(-18);
    if(button.dataset.camera==='out')engine.camera.zoom(18);
    if(button.dataset.camera==='reset')engine.camera.reset();
    if(button.dataset.camera==='rotate')button.classList.toggle('active',engine.camera.rotate());
  }));
  document.querySelectorAll('[data-preset]').forEach(button=>button.addEventListener('click',()=>{
    const layer=activeLayer();if(!layer)return;
    const presets={face:[FACE,0],vortex:[1,1],supernova:[7,3],lorenz:[9,4],synapse:[0,0]};
    [layer.effectIndex,layer.paletteIndex]=presets[button.dataset.preset];
    layer.recolor();updateOptionStates();renderLayerControls();
    engine.shockwave(innerWidth/2,innerHeight/2);
  }));
  addEventListener('pagehide',()=>{if(engine){engine.destroy();engine=null;}clearTimeout(loadTimeout);},{once:true});
  reducedMotion.addEventListener?.('change',()=>{});
  window.VirginiaHome={speak(on){engine?.speak?.(on);},burst(x=innerWidth/2,y=innerHeight/2){engine?.shockwave?.(x,y);}};
  loadThree();
})();
