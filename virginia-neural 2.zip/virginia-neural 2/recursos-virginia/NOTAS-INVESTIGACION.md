# Virginia en partículas — notas de investigación

Proyecto: VIRGIN.IA / Virginia (Neural Expressive). 21-oct-2026.

## 1. Material de partida (`01-referencias-originales/`)

| Archivo | Qué aportó |
| --- | --- |
| `EXCELENTE-VIRGINIADEFINITIVO.html` | Look Neural Expressive: escenario azul marino #020617, acentos menta #68dcb3, viñeta, tipografías Manrope / DM Sans / DM Mono. |
| `neural_expressive_ai_engine_muy_bueno.html` | Física de partículas por resortes, formaciones (vórtice, supernova, Lorenz, sinapsis), explosión al clic. |
| `virginia-home-neural_1.js / _2.js` | Malla neural entre partículas vecinas, barrido de escaneo, paletas duotono. |
| `virginia-face-mesh_1.js` | Idea del rig facial: regiones de ojos, cejas y boca que se deforman. |
| `gemini-code-*.html`, `neural-expressive-avatar.svg`, `virginia-presentacion_1.zip` | Textos, logotipo y estética de presentación. |
| `Captura ... 15.33.49.png` | **Foto de referencia de Virginia** (rubia de rizos dorados, blazer dorado, sonrisa). |
| `Captura ... 15.33.38.png / 15.35.55.png` | Primera versión procedural, rechazada por parecer caricatura. |

Decisión clave: **el rostro se construye desde la foto real**, nunca con geometría inventada.

## 2. Proceso de la imagen (`02-proceso-foto/`)

1. `01-referencia-recorte.png` — recorte cuadrado de la captura 15.33.49 (1086×828) centrado en el rostro, llevado a 1024×1024.
2. Fondo eliminado: el canal alfa es la silueta de cabello, rostro, cuello y blazer (`02-color-con-transparencia.png`).
3. Mapa de profundidad monocular generado por IA a partir del recorte (claro = cerca) y re-alineado a la silueta
   (mejor ajuste: escala 0.985, dx +3 px, dy +8 px, coincidencia IoU 0.968) → `03-profundidad.png`.
4. `04-profundidad-color.png` — la profundidad en falso color para revisarla.
5. `05-capas-lado-a-lado.png` — color, alfa y profundidad juntos.
6. Los archivos que usa el sitio son 640×640 WebP calidad 92: `src/assets/virginia-portrait.webp` y `virginia-depth.webp`.

### Mediciones (px sobre la referencia 1024)

- Ojo izq. (407,388) · ojo der. (565,369) · ceja izq. (407,345) · ceja der. (560,328)
- Nariz (485,475) · centro boca (501,545) · comisuras (425,540) / (577,522)
- Labio sup. (500,512) · dientes (500,560) · labio inf. (500,592) · mentón (495,675)
- Inclinación natural de la cabeza: −6.86° (eje de los ojos).
- Profundidad (0–255, blur 6 px): nariz 255, boca 199, mentón 189, mejilla 178, frente 172, ojos ≈130, cuello 103, cabello 98, blazer 92.
- Paso a 3D: `z = profundidad × 0.65 − 0.36`.
- Color (rojo relativo `(r−g)/r`): piel ≈ 0.30, labios ≈ 0.40–0.45, dientes ≈ 0.11.

## 3. Cómo se arma el rostro (`src/lib/virginia/portrait.ts`)

- La foto se lee en un canvas y se muestrea con **rejilla hexagonal**: fina en el óvalo del rostro (≈60 % de los puntos),
  gruesa (×1.55) en cabello y blazer, más muestreo por importancia en ojos, cejas y labios (≈35 %) y un halo (≈5 %).
- Transición fina → gruesa con **umbral de ruido espacial complementario**: cada zona pertenece a una sola rejilla,
  sin solapes (que con brillo aditivo dibujaban un óvalo luminoso) ni huecos.
- Borde rostro/cabello: puntos 40 % más grandes con color compensado `1/f²` (tapa huecos del salto de profundidad).
- Cada punto toma color de la foto y profundidad del mapa, y una región del rig (ojo, ceja, labio, mandíbula, cuello…).
- El rig mueve las regiones: parpadeo, mirada que sigue al cursor, cejas, sonrisa por comisuras y apertura de mandíbula
  con corte nítido solo entre los labios (fuera de la boca la piel se estira, sin "raja" en las mejillas).

## 4. Motor (`src/lib/virginia/engine.ts`)

- Three.js, shader de puntos aditivo, física de resortes, 5 formaciones, paleta "Retrato" (color real) + 6 duotonos.
- Color natural: `pow(c, 1.22) × 1.55` para recuperar el contraste de la foto.
- Tinte de labios en duotono solo donde `(r−g)/r > 0.4`.
- Tamaño de punto: `2.05 × spacing × escala × alto / (2·tan(fov/2) × 260)`.
- Malla neural: opacidad 0.16 en "Retrato", 0.42 en duotonos. Barrido de escaneo suave (0.22).

## 5. Problemas y soluciones

| Problema | Causa | Solución |
| --- | --- | --- |
| Rostro de caricatura | Modelo procedural | Muestreo de la foto real + profundidad |
| Rostro oscuro y plano | Puntos pequeños, malla dominante | Curva de color, puntos más grandes, malla más tenue |
| Recuadro gris sobre la boca (duotono) | El tinte de labios pintaba toda la caja | Tinte por umbral de rojo relativo |
| Boca tipo "Joker" en Sorpresa | La mandíbula se abría en todo el ancho | Corte solo entre labios, estiramiento afuera |
| Huecos en el nacimiento del pelo | Salto de profundidad al girar | Puntos de borde más grandes |
| Óvalo luminoso alrededor del rostro | Rejillas solapadas + brillo aditivo | Transición complementaria por ruido |

## 6. Scripts (`03-scripts/`)

- `shot.py` — capturas escritorio/móvil, expresiones, paleta esmeralda y FPS (Playwright, sitio en localhost:8080).
- `lipstats.js` — en la consola del navegador: cuenta puntos de piel vs labio en la boca.
- `procesar_capas.py` — regenera las imágenes de `02-proceso-foto/` desde los WebP del sitio.

## 7. Capturas (`04-capturas/`)

Estado final del retrato: escritorio, móvil, sonrisa, sorpresa y paleta esmeralda.
