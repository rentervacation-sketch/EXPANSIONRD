import { createFileRoute } from "@tanstack/react-router";
import { VirginiaStage } from "@/components/virginia/VirginiaStage";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Virginia · Rostro Neural Expressive | VIRGIN.IA" },
      {
        name: "description",
        content: "El rostro de Virginia, la IA inmobiliaria de la Península, hecho de miles de partículas neurales que miran, parpadean, hablan y reaccionan a tu voz.",
      },
      { property: "og:title", content: "Virginia · Rostro Neural Expressive" },
      {
        property: "og:description",
        content: "Un rostro de partículas WebGL que te sigue con la mirada, habla y reacciona a tu voz.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return <VirginiaStage />;
}
