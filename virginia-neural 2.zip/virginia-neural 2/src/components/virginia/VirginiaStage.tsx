import { useCallback, useEffect, useRef, useState } from "react";
import type { Engine, Mode } from "@/lib/virginia/engine";
import type { Expression } from "@/lib/virginia/portrait";

const PALETTE_PREVIEW = [
  { name: "Retrato real", a: "#e8c48a", b: "#a8754a" },
  { name: "Neural Emerald", a: "#34d399", b: "#06b6d4" },
  { name: "Aurora Borealis", a: "#2dd4bf", b: "#818cf8" },
  { name: "Glacier Ice", a: "#7dd3fc", b: "#0ea5e9" },
  { name: "Quantum Opal", a: "#f9a8d4", b: "#38bdf8" },
  { name: "Golden Horizon", a: "#fcd34d", b: "#f59e0b" },
  { name: "Monochrome Luxe", a: "#f8fafc", b: "#64748b" },
];

const EXPRESSIONS: { id: Expression; label: string }[] = [
  { id: "neutral", label: "Serena" },
  { id: "smile", label: "Sonrisa" },
  { id: "surprise", label: "Sorpresa" },
  { id: "thoughtful", label: "Pensativa" },
];

const MODES: { id: Mode; label: string }[] = [
  { id: "face", label: "Rostro" },
  { id: "vortex", label: "Vórtice" },
  { id: "supernova", label: "Supernova" },
  { id: "lorenz", label: "Lorenz" },
  { id: "synapse", label: "Sinapsis" },
];

const GREETING =
  "Hola, soy Virginia. Soy la inteligencia artificial de Expansion, especializada en bienes raíces de la Península. Conecto inventario, demanda y decisiones, para que tu agencia crezca con claridad.";

function pickVoice(): SpeechSynthesisVoice | undefined {
  const voices = window.speechSynthesis?.getVoices() ?? [];
  const es = voices.filter((v) => v.lang.toLowerCase().startsWith("es"));
  const female = /paulina|m[oó]nica|sabina|helena|elvira|dalia|laura|lucia|luc[ií]a|marisol|google español|female|mujer/i;
  return (
    es.find((v) => /mx|us|419/i.test(v.lang) && female.test(v.name)) ??
    es.find((v) => female.test(v.name)) ??
    es.find((v) => /mx|419|us/i.test(v.lang)) ??
    es[0]
  );
}

export function VirginiaStage() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const [status, setStatus] = useState<"loading" | "ready" | "error">("loading");
  const [mode, setMode] = useState<Mode>("face");
  const [expression, setExpression] = useState<Expression>("neutral");
  const [palette, setPalette] = useState(0);
  const [speaking, setSpeaking] = useState(false);
  const [mic, setMic] = useState<"off" | "on" | "denied">("off");
  const [orbit, setOrbit] = useState(false);
  const [level, setLevel] = useState(0);

  useEffect(() => {
    let disposed = false;
    let engine: Engine | null = null;
    (async () => {
      try {
        const [THREE, mod, portrait] = await Promise.all([
          import("three"),
          import("@/lib/virginia/engine"),
          import("@/lib/virginia/portrait"),
        ]);
        const source = await portrait.loadPortraitSource();
        if (disposed || !canvasRef.current) return;
        engine = mod.createEngine(THREE, canvasRef.current, {
          source,
          onReady: () => !disposed && setStatus("ready"),
          onModeChange: (m) => !disposed && setMode(m),
        });
        engineRef.current = engine;
      } catch (err) {
        console.error(err);
        if (!disposed) setStatus("error");
      }
    })();
    return () => {
      disposed = true;
      window.speechSynthesis?.cancel();
      engine?.destroy();
      engineRef.current = null;
    };
  }, []);

  // Medidor de audio del micrófono.
  useEffect(() => {
    if (mic !== "on") return;
    let raf = 0;
    const tick = () => {
      setLevel(engineRef.current?.audioLevel ?? 0);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [mic]);

  const changeMode = useCallback((m: Mode) => {
    engineRef.current?.setMode(m);
    setMode(m);
  }, []);

  const changeExpression = useCallback((e: Expression) => {
    engineRef.current?.setExpression(e);
    setExpression(e);
  }, []);

  const changePalette = useCallback((i: number) => {
    engineRef.current?.setPalette(i);
    setPalette(i);
  }, []);

  const speak = useCallback(() => {
    const engine = engineRef.current;
    if (!engine) return;
    if (mode !== "face") changeMode("face");
    const synth = window.speechSynthesis;
    if (speaking) {
      synth?.cancel();
      engine.speak(false);
      setSpeaking(false);
      return;
    }
    const done = () => {
      engine.speak(false);
      setSpeaking(false);
      changeExpression("smile");
    };
    setSpeaking(true);
    engine.speak(true);
    changeExpression("neutral");
    if (!synth || typeof SpeechSynthesisUtterance === "undefined") {
      window.setTimeout(done, 6000);
      return;
    }
    synth.cancel();
    const u = new SpeechSynthesisUtterance(GREETING);
    u.lang = "es-MX";
    const voice = pickVoice();
    if (voice) u.voice = voice;
    u.rate = 1;
    u.pitch = 1.08;
    u.onend = done;
    u.onerror = done;
    synth.speak(u);
  }, [speaking, mode, changeMode, changeExpression]);

  const toggleMic = useCallback(async () => {
    const engine = engineRef.current;
    if (!engine) return;
    if (mic === "on") {
      engine.disableMic();
      setMic("off");
      setLevel(0);
      return;
    }
    const ok = await engine.enableMic();
    setMic(ok ? "on" : "denied");
    if (ok && mode !== "face") changeMode("face");
  }, [mic, mode, changeMode]);

  const bars = [0.55, 0.85, 1, 0.75, 0.5];

  return (
    <main className="ne-stage fixed inset-0 overflow-hidden text-foreground">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 h-full w-full cursor-crosshair"
        style={{ touchAction: "none" }}
        aria-label="Rostro de Virginia formado por partículas neurales"
      />
      <div className="ne-vignette pointer-events-none absolute inset-0" aria-hidden="true" />

      {/* Cabecera */}
      <header className="pointer-events-none absolute inset-x-0 top-0 z-10 flex items-center justify-between px-5 py-5 md:px-12">
        <a href="/" data-ui className="pointer-events-auto flex items-center gap-3">
          <span className="grid h-9 w-9 -rotate-6 grid-cols-2 gap-[3px] p-0.5" aria-hidden="true">
            <i className="rounded-[1px] bg-mint" />
            <i className="translate-y-1 rounded-[1px] bg-mint opacity-70" />
            <i className="-translate-y-1 rounded-[1px] bg-mint opacity-45" />
            <i className="rounded-[1px] bg-mint opacity-90" />
          </span>
          <span>
            <b className="block font-mono text-xs font-medium tracking-[0.14em]">
              VIRGIN<em className="not-italic text-mint">.</em>IA
            </b>
            <small className="ne-label mt-1 block text-[0.5rem] text-faint">Neural Expressive</small>
          </span>
        </a>

        <div data-ui className="ne-glass pointer-events-auto hidden items-center gap-2 rounded-full px-3 py-2 md:flex" aria-label="Paleta de color">
          <span className="ne-label pl-1 pr-1 text-faint">Paleta</span>
          {PALETTE_PREVIEW.map((p, i) => (
            <button
              key={p.name}
              type="button"
              title={p.name}
              aria-label={`Paleta ${p.name}`}
              data-active={palette === i}
              onClick={() => changePalette(i)}
              className="ne-swatch"
              style={{ background: `linear-gradient(135deg, ${p.a}, ${p.b})` }}
            />
          ))}
        </div>
      </header>

      {/* Texto principal */}
      <section className="pointer-events-none absolute inset-x-0 bottom-32 z-[5] px-6 text-center md:bottom-auto md:left-[clamp(24px,6vw,96px)] md:right-auto md:top-1/2 md:max-w-[min(560px,44vw)] md:-translate-y-1/2 md:px-0 md:text-left">
        <div className="ne-fade-in">
          <div className="ne-glass ne-label mb-6 hidden items-center md:inline-flex gap-3 rounded-full px-4 py-2 text-accent-foreground">
            <span className="ne-dot" /> Inteligencia inmobiliaria
            <i className="h-px w-4 bg-border" /> Virgin.IA
          </div>
          <h1 className="font-display text-[clamp(2.4rem,5.4vw,4.75rem)] font-medium leading-[1.02] tracking-[-0.05em]">
            Hola, soy <span className="ne-wave">Virginia</span>
          </h1>
          <p className="mx-auto mt-5 max-w-md text-sm leading-relaxed text-muted-foreground md:mx-0 md:text-base">
            Tu inteligencia artificial para el Real Estate de la Península.
            <span className="hidden md:inline"> Mírame a los ojos: te sigo con la mirada.</span>
          </p>
          <div data-ui className="pointer-events-auto mt-6 flex flex-wrap justify-center gap-3 md:justify-start">
            <button type="button" className="ne-btn ne-btn-primary" onClick={speak} disabled={status !== "ready"}>
              {speaking ? "Detener voz" : "Escuchar a Virginia"}
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
                {speaking ? <path d="M7 7h10v10H7z" /> : <path d="M11 5 6 9H3v6h3l5 4V5ZM15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13" />}
              </svg>
            </button>
            <button type="button" className="ne-btn ne-btn-quiet" data-active={mic === "on"} onClick={toggleMic} disabled={status !== "ready"}>
              {mic === "on" ? (
                <span className="flex h-4 items-end gap-[3px]" aria-hidden="true">
                  {bars.map((b, i) => (
                    <i key={i} className="ne-meter" style={{ height: `${Math.max(3, Math.min(16, 3 + level * 40 * b))}px` }} />
                  ))}
                </span>
              ) : (
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
                  <rect x="9" y="3" width="6" height="11" rx="3" />
                  <path d="M5 11a7 7 0 0 0 14 0M12 18v3" />
                </svg>
              )}
              {mic === "on" ? "Micrófono activo" : "Háblale"}
            </button>
          </div>
          <p className="ne-label mt-4 min-h-4 text-faint">
            {status === "loading" && "Iniciando campo neural…"}
            {status === "error" && "Tu navegador no pudo iniciar el motor 3D."}
            {status === "ready" && mic === "denied" && "Permite el micrófono para que Virginia te responda con la boca."}
            {status === "ready" && mic === "on" && "Habla: su boca y el halo reaccionan a tu voz."}
          </p>
        </div>
      </section>

      {/* Expresiones */}
      <div
        data-ui
        className="ne-glass absolute bottom-[4.25rem] left-1/2 z-10 flex -translate-x-1/2 items-center gap-1 rounded-full p-1 md:bottom-[5.5rem] md:left-[clamp(24px,6vw,96px)] md:translate-x-0 min-[1700px]:bottom-8 min-[1700px]:left-auto min-[1700px]:right-[clamp(24px,4.5vw,68px)]"
        aria-label="Expresiones"
      >
        <span className="ne-label hidden px-2 text-faint sm:inline">Expresión</span>
        {EXPRESSIONS.map((e) => (
          <button key={e.id} type="button" className="ne-chip" data-active={expression === e.id} onClick={() => changeExpression(e.id)}>
            {e.label}
          </button>
        ))}
      </div>

      {/* Formaciones */}
      <div
        data-ui
        className="ne-glass absolute bottom-4 left-1/2 z-10 flex max-w-[calc(100vw-24px)] -translate-x-1/2 items-center gap-1 overflow-x-auto rounded-full p-1 md:bottom-8 md:left-[clamp(24px,6vw,96px)] md:translate-x-0"
        aria-label="Formaciones de partículas"
      >
        <span className="ne-label hidden px-2 text-faint sm:inline">Vistas</span>
        {MODES.map((m) => (
          <button key={m.id} type="button" className="ne-chip" data-active={mode === m.id} onClick={() => changeMode(m.id)}>
            {m.label}
          </button>
        ))}
      </div>

      {/* Cámara */}
      <div data-ui className="absolute right-4 top-1/2 z-10 hidden -translate-y-1/2 flex-col gap-2 md:flex" aria-label="Controles de cámara">
        <button type="button" className="ne-icon-btn" aria-label="Acercar" title="Acercar" onClick={() => engineRef.current?.zoom(1)}>
          ＋
        </button>
        <button type="button" className="ne-icon-btn" aria-label="Alejar" title="Alejar" onClick={() => engineRef.current?.zoom(-1)}>
          −
        </button>
        <button
          type="button"
          className="ne-icon-btn"
          aria-label="Restablecer vista"
          title="Restablecer vista"
          onClick={() => {
            engineRef.current?.resetView();
            setOrbit(false);
          }}
        >
          ↺
        </button>
        <button
          type="button"
          className="ne-icon-btn"
          aria-label="Órbita automática"
          title="Órbita automática"
          data-active={orbit}
          onClick={() => setOrbit(engineRef.current?.toggleAutoRotate() ?? false)}
        >
          ◎
        </button>
        <button type="button" className="ne-icon-btn" aria-label="Explosión" title="Explosión" onClick={() => engineRef.current?.burstCenter()}>
          ✦
        </button>
      </div>

      {/* Pie */}
      <div className="ne-label pointer-events-none absolute right-[clamp(24px,4.5vw,68px)] top-24 z-[5] hidden flex-col items-end gap-1.5 text-faint md:flex">
        <span>21°09' N</span>
        <span>87°04' W</span>
      </div>
      <div className="ne-label pointer-events-none absolute inset-x-0 bottom-[0.35rem] z-[5] hidden justify-center text-[0.5rem] text-faint/70 lg:flex">
        Cursor: mirada · Clic: explosión · Clic derecho: órbita · Rueda: zoom · Doble clic: centrar
      </div>
    </main>
  );
}
