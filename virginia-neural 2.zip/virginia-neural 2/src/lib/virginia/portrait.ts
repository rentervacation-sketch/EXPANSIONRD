// @ts-nocheck -- hot numeric kernel: typed-array indexing in tight loops conflicts with noUncheckedIndexedAccess; runtime-verified.
/*
 * VIRGIN.IA — Retrato de Virginia en partículas (Neural Expressive)
 * ---------------------------------------------------------------------------
 * Las partículas se muestrean de la fotografía real de Virginia (color) y de su
 * mapa de profundidad (relieve 3D). Una rejilla hexagonal da la malla neural y
 * un muestreo por importancia (bordes, ojos, cejas, labios, rizos) conserva el
 * parecido. El rig deforma regiones anatómicas medidas sobre la foto: mirada,
 * parpadeo, cejas, boca que habla (mandíbula) y comisuras.
 *
 * Coordenadas de referencia: píxeles de la foto a 1024×1024 (REF). El marco
 * "facial" (u, v) está girado para que la línea de los ojos quede horizontal.
 */
import colorUrl from "@/assets/virginia-portrait.webp";
import depthUrl from "@/assets/virginia-depth.webp";

export const KIND = { skin: 0, eye: 1, lip: 2, line: 3, iris: 4, pupil: 5, hair: 6, neck: 7, halo: 8, body: 9 } as const;
export const GROUP = { lattice: 0, feature: 1, neck: 2, hair: 3, halo: 4 } as const;

export type PortraitSource = { size: number; rgba: Uint8ClampedArray; depth: Uint8ClampedArray };

const REF = 1024;
const U = 400; // píxeles REF por unidad de escena
const ORIGIN_X = 505;
const ORIGIN_Y = 500;
const PIVOT_Y = -(640 - ORIGIN_Y) / U; // cuello
// Marco facial
const FC_X = 500;
const FC_Y = 450;
const TILT = Math.atan2(369 - 388, 565 - 407); // inclinación natural de la cabeza (rad)
const TC = Math.cos(TILT);
const TS = Math.sin(TILT);
// Puntos anatómicos en el marco facial (px REF)
const EYES = [
  { u: -85, v: -72.7 },
  { u: 74.2, v: -72.7 },
];
const BROWS = [
  { u: -80, v: -115 },
  { u: 74, v: -114 },
];
const MOUTH_U = -8.6;
const MOUTH_HALF = 76.5;
const CORNER_V = 80.5;
const SPLIT_V = 109;
const LOWER_LIP_V = 141;
const UPPER_LIP_V = 61.6;
const CHIN_V = 223;
// Torso (cuello + ropa) en px REF sin girar: rota menos que la cabeza.
const TORSO: [number, number][] = [
  [420, 640], [600, 630], [660, 660], [720, 705], [860, 770], [1024, 800], [1024, 1024],
  [270, 1024], [300, 860], [380, 760], [410, 700],
];

const sstep = (a: number, b: number, x: number) => {
  const t = Math.min(1, Math.max(0, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
};

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function inPoly(x: number, y: number, poly: [number, number][]) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i, i += 1) {
    const [xi, yi] = poly[i];
    const [xj, yj] = poly[j];
    if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}

const toFace = (x: number, y: number) => {
  const dx = x - FC_X;
  const dy = y - FC_Y;
  return [dx * TC + dy * TS, -dx * TS + dy * TC];
};

function splitV(u: number) {
  const d = Math.abs(u - MOUTH_U);
  if (d <= MOUTH_HALF) return CORNER_V + (SPLIT_V - CORNER_V) * (1 - (d / MOUTH_HALF) ** 2);
  return CORNER_V - (d - MOUTH_HALF) * 0.3;
}

/** Ruido de valor suave y determinista en [0,1]. */
function vnoise(x: number, y: number) {
  const h = (i: number, j: number) => {
    const s = Math.sin(i * 127.1 + j * 311.7) * 43758.5453;
    return s - Math.floor(s);
  };
  const xi = Math.floor(x);
  const yi = Math.floor(y);
  const fx = x - xi;
  const fy = y - yi;
  const ux = fx * fx * (3 - 2 * fx);
  const uy = fy * fy * (3 - 2 * fy);
  const a = h(xi, yi) + (h(xi + 1, yi) - h(xi, yi)) * ux;
  const b = h(xi, yi + 1) + (h(xi + 1, yi + 1) - h(xi, yi + 1)) * ux;
  return a + (b - a) * uy;
}

/** Carga la foto y su profundidad en memoria (solo navegador). */
export async function loadPortraitSource(size = 640): Promise<PortraitSource> {
  const load = (src: string) =>
    new Promise<HTMLImageElement>((resolve, reject) => {
      const img = new Image();
      img.decoding = "async";
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error("No se pudo cargar " + src));
      img.src = src;
    });
  const [ci, di] = await Promise.all([load(colorUrl), load(depthUrl)]);
  const cv = document.createElement("canvas");
  cv.width = size;
  cv.height = size;
  const ctx = cv.getContext("2d", { willReadFrequently: true });
  ctx.drawImage(ci, 0, 0, size, size);
  const rgba = ctx.getImageData(0, 0, size, size).data;
  ctx.clearRect(0, 0, size, size);
  ctx.drawImage(di, 0, 0, size, size);
  const dd = ctx.getImageData(0, 0, size, size).data;
  const depth = new Uint8ClampedArray(size * size);
  for (let i = 0; i < size * size; i += 1) depth[i] = dd[i * 4];
  return { size, rgba: new Uint8ClampedArray(rgba), depth };
}

export type FaceModel = ReturnType<typeof generate>;

/**
 * @param src  foto + profundidad
 * @param total número total de partículas (retrato + halo)
 */
export function generate(src: PortraitSource, total: number) {
  const rnd = mulberry32(20261021);
  const W = src.size;
  const k = REF / W;
  const P = W * W;
  const alpha = new Float32Array(P);
  const lum = new Float32Array(P);
  for (let i = 0; i < P; i += 1) {
    const r = src.rgba[i * 4];
    const g = src.rgba[i * 4 + 1];
    const b = src.rgba[i * 4 + 2];
    alpha[i] = src.rgba[i * 4 + 3] / 255;
    lum[i] = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
  }
  const fade = (yRef: number) => 1 - sstep(840, 1010, yRef);

  const sampleC = (x: number, y: number, out: number[]) => {
    const xi = Math.min(W - 1, Math.max(0, Math.round(x)));
    const yi = Math.min(W - 1, Math.max(0, Math.round(y)));
    const p = (yi * W + xi) * 4;
    out[0] = src.rgba[p] / 255;
    out[1] = src.rgba[p + 1] / 255;
    out[2] = src.rgba[p + 2] / 255;
    out[3] = src.rgba[p + 3] / 255;
    return out;
  };
  const sampleD = (x: number, y: number) => {
    const x0 = Math.min(W - 2, Math.max(0, Math.floor(x)));
    const y0 = Math.min(W - 2, Math.max(0, Math.floor(y)));
    const fx = Math.min(1, Math.max(0, x - x0));
    const fy = Math.min(1, Math.max(0, y - y0));
    const d = src.depth;
    const a = d[y0 * W + x0] * (1 - fx) + d[y0 * W + x0 + 1] * fx;
    const b = d[(y0 + 1) * W + x0] * (1 - fx) + d[(y0 + 1) * W + x0 + 1] * fx;
    return (a * (1 - fy) + b * fy) / 255;
  };
  const alphaAt = (x: number, y: number) => {
    const xi = Math.min(W - 1, Math.max(0, Math.round(x)));
    const yi = Math.min(W - 1, Math.max(0, Math.round(y)));
    return alpha[yi * W + xi];
  };
  const featureBoost = (xr: number, yr: number) => {
    const [u, v] = toFace(xr, yr);
    let b = 0;
    for (const e of EYES) b += Math.exp(-(((u - e.u) / 48) ** 2) - ((v - e.v) / 24) ** 2) * 2.2;
    for (const e of BROWS) b += Math.exp(-(((u - e.u) / 60) ** 2) - ((v - e.v) / 16) ** 2) * 1.1;
    b += Math.exp(-(((u - MOUTH_U) / 95) ** 2) - ((v - 100) / 48) ** 2) * 1.6;
    b += Math.exp(-(((u + 15) / 40) ** 2) - ((v - 15) / 45) ** 2) * 0.7; // nariz
    return b;
  };

  // 1 · Gradiente (Sobel) para el muestreo por importancia.
  const grad = new Float32Array(P);
  let gmax = 0;
  for (let y = 1; y < W - 1; y += 1) {
    for (let x = 1; x < W - 1; x += 1) {
      const i = y * W + x;
      const gx = lum[i - W + 1] + 2 * lum[i + 1] + lum[i + W + 1] - lum[i - W - 1] - 2 * lum[i - 1] - lum[i + W - 1];
      const gy = lum[i + W - 1] + 2 * lum[i + W] + lum[i + W + 1] - lum[i - W - 1] - 2 * lum[i - W] - lum[i - W + 1];
      const g = Math.hypot(gx, gy);
      grad[i] = g;
      if (g > gmax) gmax = g;
    }
  }
  const gnorm = 1 / Math.max(1e-6, gmax * 0.45);

  // 2 · Rejillas hexagonales: densa sobre el rostro (malla neural), más abierta en cabello y ropa.
  // Pertenencia al rostro con borde difuminado (evita un óvalo marcado entre rejillas).
  const faceOv = (xr: number, yr: number) => {
    const [u, v] = toFace(xr, yr);
    return ((u - 5) / 172) ** 2 + ((v + 10) / 242) ** 2;
  };
  const isFaceRef = (xr: number, yr: number) => faceOv(xr, yr) <= 1;
  const COARSE = 1.55;
  let areaF = 0;
  let areaH = 0;
  for (let y = 0; y < W; y += 1) {
    const f = fade(y * k);
    for (let x = 0; x < W; x += 1) {
      if (alpha[y * W + x] <= 0.5) continue;
      if (isFaceRef(x * k, y * k)) areaF += f;
      else areaH += f;
    }
  }
  const latticeTarget = Math.floor(total * 0.6);
  const detailTarget = Math.floor(total * 0.35);
  const spacing = Math.sqrt((2 * (areaF + areaH / (COARSE * COARSE))) / (Math.sqrt(3) * latticeTarget));
  type LP = { x: number; y: number; r: number; c: number; fine: boolean };
  const lat: LP[] = [];
  const latIndex = new Map<string, number>();
  const buildLattice = (sp: number, fine: boolean) => {
    const rowH = (sp * Math.sqrt(3)) / 2;
    for (let r = 0, y = rowH * 0.5; y < W; r += 1, y += rowH) {
      const off = r % 2 ? sp / 2 : 0;
      const f = fade(y * k);
      for (let c = 0, x = off + sp * 0.25; x < W; c += 1, x += sp) {
        if (alphaAt(x, y) <= 0.5) continue;
        // Fina: hasta el borde difuso; gruesa: entra con probabilidad creciente. Se solapan para no dejar huecos.
        // Transición complementaria: el mismo umbral espacial decide fina o gruesa, sin solapes (óvalo brillante) ni huecos.
        const pf = 1 - sstep(0.86, 1.08, faceOv(x * k, y * k));
        const th = 0.15 + 0.7 * vnoise(x * k * 0.06, y * k * 0.06);
        if (fine ? pf <= th : pf > th) continue;
        if (f < 1 && rnd() > f) continue;
        if (fine) latIndex.set(r + "," + c, lat.length);
        lat.push({ x, y, r, c, fine });
      }
    }
  };
  buildLattice(spacing, true);
  buildLattice(spacing * COARSE, false);

  // 3 · Puntos de detalle (CDF de importancia).
  const cdf = new Float64Array(P);
  let acc = 0;
  for (let y = 0; y < W; y += 1) {
    const f = fade(y * k);
    for (let x = 0; x < W; x += 1) {
      const i = y * W + x;
      let imp = 0;
      if (alpha[i] > 0.4 && f > 0) {
        imp = alpha[i] * f * (0.12 + Math.min(1.6, grad[i] * gnorm)) * (1 + featureBoost(x * k, y * k));
      }
      acc += imp;
      cdf[i] = acc;
    }
  }
  const det: { x: number; y: number }[] = [];
  for (let d = 0; d < detailTarget && acc > 0; d += 1) {
    const t = rnd() * acc;
    let lo = 0;
    let hi = P - 1;
    while (lo < hi) {
      const mid = (lo + hi) >> 1;
      if (cdf[mid] < t) lo = mid + 1;
      else hi = mid;
    }
    det.push({ x: (lo % W) + rnd(), y: Math.floor(lo / W) + rnd() });
  }

  const L = lat.length;
  const D = det.length;
  const haloCount = Math.max(0, total - L - D);
  const n = L + D + haloCount;

  const pos = new Float32Array(n * 3);
  const fu = new Float32Array(n);
  const fv = new Float32Array(n);
  const color = new Float32Array(n * 3);
  const shade = new Float32Array(n);
  const kind = new Uint8Array(n);
  const group = new Uint8Array(n);
  const size = new Float32Array(n);
  const seed = new Float32Array(n);
  const tone = new Float32Array(n);
  const eyeW = new Float32Array(n);
  const eyeCy = new Float32Array(n);
  const irisW = new Float32Array(n);
  const browW = new Float32Array(n);
  const jawW = new Float32Array(n);
  const lipW = new Float32Array(n);
  const cornerW = new Float32Array(n);
  const sway = new Float32Array(n);
  const amt = new Float32Array(n);
  const faceMask = new Uint8Array(n);
  const c4 = [0, 0, 0, 0];

  const setPoint = (i: number, x: number, y: number, isLattice: boolean, coarse = false) => {
    const xr = x * k;
    const yr = y * k;
    sampleC(x, y, c4);
    color[i * 3] = c4[0];
    color[i * 3 + 1] = c4[1];
    color[i * 3 + 2] = c4[2];
    const l = 0.2126 * c4[0] + 0.7152 * c4[1] + 0.0722 * c4[2];
    shade[i] = l;
    tone[i] = l;
    pos[i * 3] = (xr - ORIGIN_X) / U;
    pos[i * 3 + 1] = -(yr - ORIGIN_Y) / U;
    pos[i * 3 + 2] = sampleD(x, y) * 0.65 - 0.36;
    const [u, v] = toFace(xr, yr);
    fu[i] = u;
    fv[i] = v;
    seed[i] = rnd();
    size[i] = isLattice ? (coarse ? COARSE * 0.95 : 1) : 0.62 + rnd() * 0.3;
    group[i] = isLattice ? GROUP.lattice : GROUP.feature;

    const ov = ((u - 5) / 168) ** 2 + ((v + 10) / 238) ** 2;
    const face = 1 - sstep(0.82, 1.0, ov);
    const torso = inPoly(xr, yr, TORSO);
    faceMask[i] = face > 0.5 || (torso && yr < 760 && Math.abs(xr - 510) < 95) ? 1 : 0;

    if (torso && face < 0.5) {
      kind[i] = yr < 760 && Math.abs(xr - 510) < 95 ? KIND.neck : KIND.body;
      group[i] = GROUP.neck;
      amt[i] = 0.22 + 0.5 * (1 - sstep(650, 760, yr)) * (Math.abs(xr - 510) < 120 ? 1 : 0);
    } else if (face >= 0.5) {
      kind[i] = KIND.skin;
      amt[i] = 1;
    } else {
      kind[i] = KIND.hair;
      group[i] = GROUP.hair;
      amt[i] = 1 - 0.55 * sstep(640, 940, yr);
      sway[i] = sstep(250, 900, yr) * (0.4 + 0.6 * sstep(120, 300, Math.abs(xr - 505)));
    }

    // Ojos
    for (const e of EYES) {
      const du = u - e.u;
      const dv = v - e.v;
      const w = Math.exp(-((du / 40) ** 4) - (dv / 21) ** 4);
      if (w > eyeW[i]) {
        eyeW[i] = w > 0.05 ? w : 0;
        eyeCy[i] = e.v + 4;
      }
      const dr = Math.hypot(du, dv);
      const iw = 1 - sstep(11, 16, dr);
      if (iw > irisW[i]) irisW[i] = iw;
      if (dr < 15 && face > 0.5) kind[i] = dr < 6 && l < 0.25 ? KIND.pupil : KIND.iris;
      else if (w > 0.6 && face > 0.5 && kind[i] === KIND.skin) kind[i] = KIND.eye;
    }
    // Cejas
    for (const b of BROWS) {
      const w = Math.exp(-(((u - b.u) / 55) ** 2) - ((v - b.v) / 18) ** 2);
      if (w > browW[i]) browW[i] = w > 0.04 ? w : 0;
    }
    // Boca
    const du = u - MOUTH_U;
    const sv = splitV(u);
    const inMouthX = 1 - sstep(MOUTH_HALF * 0.95, MOUTH_HALF * 1.25, Math.abs(du));
    if (v > UPPER_LIP_V - 4 && v < LOWER_LIP_V + 4 && inMouthX > 0.5 && face > 0.5) kind[i] = KIND.lip;
    if (v < sv && v > UPPER_LIP_V - 14) lipW[i] = inMouthX;
    // Mandíbula: corte nítido solo entre los labios; fuera de la boca la piel se estira (sin raja en las mejillas).
    const ext = Math.max(0, Math.abs(du) - MOUTH_HALF * 0.85);
    jawW[i] =
      face > 0.3 || kind[i] === KIND.neck
        ? sstep(sv - 1.5 - ext * 0.9, sv + 2.5 + ext * 1.6, v) *
          (1 - sstep(MOUTH_HALF * 0.8, MOUTH_HALF * 1.9, Math.abs(du))) *
          (1 - sstep(CHIN_V - 15, CHIN_V + 55, v))
        : 0;
    const cw = Math.max(
      Math.exp(-(((u - (MOUTH_U - MOUTH_HALF)) / 20) ** 2) - ((v - CORNER_V) / 20) ** 2),
      Math.exp(-(((u - (MOUTH_U + MOUTH_HALF)) / 20) ** 2) - ((v - CORNER_V) / 20) ** 2),
    );
    cornerW[i] = cw > 0.04 ? cw : 0;
    // Borde rostro/cabello: hay un salto de profundidad; puntos algo mayores evitan huecos al girar la cabeza.
    // El brillo aditivo crece con el área: se compensa el color para no dibujar un óvalo luminoso.
    if (isLattice) {
      const f = 1 + 0.4 * sstep(0.84, 0.97, ov) * (1 - sstep(1.12, 1.32, ov));
      if (f > 1.001) {
        const dim = 1 / (f * f);
        size[i] *= f;
        color[i * 3] *= dim;
        color[i * 3 + 1] *= dim;
        color[i * 3 + 2] *= dim;
        shade[i] *= dim;
      }
    }
  };

  for (let i = 0; i < L; i += 1) setPoint(i, lat[i].x, lat[i].y, true, !lat[i].fine);
  for (let d = 0; d < D; d += 1) setPoint(L + d, det[d].x, det[d].y, false);

  const haloStart = L + D;
  for (let h = 0; h < haloCount; h += 1) {
    const i = haloStart + h;
    kind[i] = KIND.halo;
    group[i] = GROUP.halo;
    size[i] = 0.5 + rnd() * 0.6;
    seed[i] = rnd();
    tone[i] = rnd();
    shade[i] = 0.5;
  }

  // Malla neural: solo sobre la piel (rostro y cuello).
  const edges: number[] = [];
  const at = (r: number, c: number) => latIndex.get(r + "," + c);
  for (let i = 0; i < L; i += 1) {
    if (!faceMask[i] || !lat[i].fine) continue;
    const { r, c } = lat[i];
    const cand = [at(r, c + 1), at(r + 1, c), at(r + 1, r % 2 ? c + 1 : c - 1)];
    for (const j of cand) if (j !== undefined && faceMask[j]) edges.push(i, j);
  }
  const edgeArr = new Uint32Array(edges);
  const rest = new Float32Array(edgeArr.length / 2);
  for (let e = 0; e < rest.length; e += 1) {
    const a = edgeArr[e * 2] * 3;
    const b = edgeArr[e * 2 + 1] * 3;
    rest[e] = Math.hypot(pos[a] - pos[b], pos[a + 1] - pos[b + 1], pos[a + 2] - pos[b + 2]);
  }

  return {
    count: n,
    haloStart,
    /** separación de la rejilla en unidades de escena */
    spacing: (spacing * k) / U,
    pos,
    fu,
    fv,
    color,
    shade,
    kind,
    group,
    size,
    seed,
    tone,
    eyeW,
    eyeCy,
    irisW,
    browW,
    jawW,
    lipW,
    cornerW,
    sway,
    amt,
    edges: edgeArr,
    rest,
  };
}

export type Expression = "neutral" | "smile" | "surprise" | "thoughtful";

type ExParams = { smile: number; brow: number; open: number; tilt: number; lookX: number; lookY: number; squint: number; widen: number };
const EXPRESSIONS: Record<Expression, ExParams> = {
  neutral: { smile: 0.55, brow: 0, open: 0, tilt: 0, lookX: 0, lookY: 0, squint: 0, widen: 0 },
  smile: { smile: 1, brow: 0.2, open: 0, tilt: 0.035, lookX: 0, lookY: 0, squint: 0.12, widen: 0 },
  surprise: { smile: 0.35, brow: 1, open: 0.5, tilt: 0, lookX: 0, lookY: 0.08, squint: 0, widen: 1 },
  thoughtful: { smile: 0.45, brow: -0.45, open: 0, tilt: -0.09, lookX: -0.6, lookY: 0.55, squint: 0.1, widen: 0 },
};

/**
 * Rig de animación sobre el retrato: mirada, parpadeo, cejas, boca, comisuras,
 * respiración y giro de cabeza. Devuelve la posición destino (unidades de mundo).
 */
export function createRig(F: FaceModel) {
  const rig = {
    face: F,
    yaw: 0,
    pitch: 0,
    roll: 0,
    gazeX: 0,
    gazeY: 0,
    blink: 0,
    blinking: false,
    blinkT: 0,
    nextBlink: 1.8,
    mouth: 0,
    speaking: false,
    audio: 0,
    expression: "neutral" as Expression,
    ex: { ...EXPRESSIONS.neutral },
    S: 30,
    scale: 30,
    time: 0,
    tv: [0, 0, 0] as [number, number, number],

    prepare(time: number, dt: number, mx: number, my: number, hasPointer: boolean) {
      rig.time = time;
      const kk = Math.min(1, dt * 60 * 0.05);
      const target = EXPRESSIONS[rig.expression];
      const ek = Math.min(1, dt * 60 * 0.07);
      for (const key of Object.keys(target) as (keyof ExParams)[]) rig.ex[key] += (target[key] - rig.ex[key]) * ek;
      let ty: number;
      let tp: number;
      let gx: number;
      let gy: number;
      if (!hasPointer) {
        ty = Math.sin(time * 0.45) * 0.12;
        tp = Math.sin(time * 0.33) * 0.04;
        gx = Math.sin(time * 0.7) * 0.4;
        gy = Math.sin(time * 0.5) * 0.2;
      } else {
        const nx = Math.max(-1, Math.min(1, mx / (rig.S * 3)));
        const ny = Math.max(-1, Math.min(1, my / (rig.S * 2.4)));
        ty = nx * 0.38;
        tp = -ny * 0.22;
        gx = nx;
        gy = ny;
      }
      ty += rig.ex.lookX * 0.1;
      tp -= rig.ex.lookY * 0.08;
      gx = Math.max(-1, Math.min(1, gx + rig.ex.lookX));
      gy = Math.max(-1, Math.min(1, gy + rig.ex.lookY));
      rig.yaw += (ty - rig.yaw) * kk;
      rig.pitch += (tp - rig.pitch) * kk;
      rig.roll += (rig.ex.tilt + Math.sin(time * 0.27) * 0.012 - rig.roll) * kk;
      rig.gazeX += (gx - rig.gazeX) * Math.min(1, dt * 60 * 0.15);
      rig.gazeY += (gy - rig.gazeY) * Math.min(1, dt * 60 * 0.15);

      if (!rig.blinking && time > rig.nextBlink) {
        rig.blinking = true;
        rig.blinkT = 0;
        rig.nextBlink = time + 2.4 + Math.random() * 3.6;
      }
      if (rig.blinking) {
        rig.blinkT += dt;
        const u = rig.blinkT / 0.2;
        if (u >= 1) {
          rig.blinking = false;
          rig.blink = 0;
        } else rig.blink = Math.sin(Math.PI * u);
      }

      let mouthTarget = rig.speaking ? Math.abs(Math.sin(time * 9.5)) * (0.55 + 0.45 * Math.sin(time * 3.3)) * 0.85 : 0;
      mouthTarget = Math.max(mouthTarget, Math.min(1, rig.audio * 2.2), rig.ex.open);
      rig.mouth += (mouthTarget - rig.mouth) * Math.min(1, dt * 60 * 0.25);

      rig.S = rig.scale * (1 + 0.006 * Math.sin(time * 1.4));
    },

    target(i: number): [number, number, number] {
      const t = rig.tv;
      const S = rig.S;
      const g = F.group[i];
      if (g === GROUP.halo) {
        const j = i - F.haloStart;
        const a = j * 2.399963 + rig.time * (0.05 + (j % 9) * 0.01);
        const hh = ((j * 0.754877) % 1) * 2 - 1;
        const rr = S * (1.45 + ((j * 0.618034) % 1) * 1.1) * Math.sqrt(1 - hh * hh * 0.85);
        t[0] = Math.cos(a) * rr;
        t[1] = hh * S * 1.5 + S * 0.1;
        t[2] = Math.sin(a) * rr * 0.6 - S * 0.6;
        return t;
      }
      const k3 = i * 3;
      let x = F.pos[k3];
      let y = F.pos[k3 + 1];
      let z = F.pos[k3 + 2];
      const ex = rig.ex;
      // Deformaciones en el marco facial (px REF; v hacia abajo).
      let du = 0;
      let dv = 0;
      const v = F.fv[i];
      const iw = F.irisW[i];
      if (iw > 0) {
        du += rig.gazeX * 5 * iw;
        dv -= rig.gazeY * 3.2 * iw;
      }
      const ew = F.eyeW[i];
      if (ew > 0) {
        const cy = F.eyeCy[i];
        const closed = Math.min(1, rig.blink + ex.squint);
        if (ex.widen > 0 && v < cy) dv -= ex.widen * 4 * ew;
        if (closed > 0) dv += (cy - (v + dv)) * ew * closed * 0.94;
      }
      const bw = F.browW[i];
      if (bw > 0) dv -= bw * ex.brow * 9 * (ex.lookX < 0 && F.fu[i] < 0 ? 1.35 : 1);
      const m = rig.mouth;
      if (m > 0.001) {
        const jw = F.jawW[i];
        if (jw > 0) dv += jw * m * 26;
        const lw = F.lipW[i];
        if (lw > 0) dv -= lw * m * 3.5;
      }
      const cw = F.cornerW[i];
      if (cw > 0) {
        const relax = 1 - ex.smile;
        dv += cw * relax * 9;
        du -= Math.sign(F.fu[i] - MOUTH_U) * cw * relax * 4;
      }
      if (du !== 0 || dv !== 0) {
        // Volver del marco facial al de la foto y a unidades de escena.
        const dx = du * TC - dv * TS;
        const dy = du * TS + dv * TC;
        x += dx / U;
        y -= dy / U;
      }
      const sw = F.sway[i];
      if (sw > 0) {
        x += Math.sin(rig.time * 0.9 + y * 3 + F.seed[i] * 1.5) * 0.008 * sw;
        z += Math.cos(rig.time * 0.7 + y * 2.4) * 0.008 * sw;
      }
      x *= S;
      y *= S;
      z *= S;
      const a = F.amt[i];
      const yaw = rig.yaw * a;
      const pitch = rig.pitch * a;
      const roll = rig.roll * a;
      const cy = Math.cos(yaw);
      const sy = Math.sin(yaw);
      const cp = Math.cos(pitch);
      const sp = Math.sin(pitch);
      const cr = Math.cos(roll);
      const sr = Math.sin(roll);
      const py = PIVOT_Y * S;
      let yy = y - py;
      const xr = x * cr - yy * sr;
      yy = x * sr + yy * cr;
      const x1 = xr * cy + z * sy;
      const z1 = -xr * sy + z * cy;
      t[0] = x1;
      t[1] = yy * cp - z1 * sp + py;
      t[2] = yy * sp + z1 * cp;
      return t;
    },

    burst(pos: Float32Array, vel: Float32Array, n: number, ox: number, oy: number) {
      const R = rig.S * 2.6;
      for (let i = 0; i < n; i += 1) {
        const ix = i * 3;
        const dx = pos[ix] - ox;
        const dy = pos[ix + 1] - oy;
        const dz = pos[ix + 2] - 14;
        const d = Math.hypot(dx, dy, dz) + 1;
        const near = Math.max(0, 1 - d / R);
        const f = (near * near * 3.4 + 0.9) * (0.7 + Math.random() * 0.6);
        vel[ix] += (dx / d) * f + (Math.random() - 0.5) * 1.1;
        vel[ix + 1] += (dy / d) * f + (Math.random() - 0.5) * 1.1;
        vel[ix + 2] += (dz / d) * f + (Math.random() - 0.5) * 2.2;
      }
    },
  };
  return rig;
}

export type Rig = ReturnType<typeof createRig>;
