// @ts-nocheck -- hot numeric kernel: typed-array indexing in tight loops conflicts with noUncheckedIndexedAccess; runtime-verified.
/*
 * VIRGIN.IA — Motor Neural Expressive (WebGL / Three.js)
 * ---------------------------------------------------------------------------
 * Física de resortes + amortiguamiento del motor neural original, aplicada al
 * rostro procedural de Virginia. Incluye: mirada que sigue al cursor, parpadeo,
 * boca reactiva (voz o micrófono), expresiones, explosión al hacer clic,
 * formaciones alternativas (vórtice, supernova, Lorenz, sinapsis), malla
 * neural, barrido de escaneo y órbita de cámara.
 */
import type * as THREE_NS from "three";
import { createRig, generate, GROUP, KIND, type Expression, type FaceModel, type PortraitSource, type Rig } from "./portrait";

export type Mode = "face" | "vortex" | "supernova" | "lorenz" | "synapse";

export type Palette = {
  name: string;
  /** usa los colores reales de la fotografía */
  natural?: boolean;
  /** sombras → medios → luces → brillo */
  colors: [string, string, string, string];
  lip: string;
  line: string;
};

export const PALETTES: Palette[] = [
  { name: "Retrato", natural: true, colors: ["#3b2a1a", "#c89b5f", "#f3d9b8", "#fff7ea"], lip: "#d98c8c", line: "#68dcb3" },
  { name: "Neural Emerald", colors: ["#04332a", "#10b981", "#5eead4", "#ecfdf5"], lip: "#fda4af", line: "#34d399" },
  { name: "Aurora Borealis", colors: ["#1e1b4b", "#6366f1", "#2dd4bf", "#e0fbf3"], lip: "#f9a8d4", line: "#2dd4bf" },
  { name: "Glacier Ice", colors: ["#082f49", "#0284c7", "#7dd3fc", "#f0f9ff"], lip: "#fbcfe8", line: "#38bdf8" },
  { name: "Quantum Opal", colors: ["#1e1b4b", "#db2777", "#7dd3fc", "#fdf2f8"], lip: "#fb7185", line: "#f9a8d4" },
  { name: "Golden Horizon", colors: ["#3b1d06", "#d97706", "#fcd34d", "#fffbeb"], lip: "#fb923c", line: "#f59e0b" },
  { name: "Monochrome Luxe", colors: ["#0f172a", "#64748b", "#cbd5e1", "#ffffff"], lip: "#e2e8f0", line: "#cbd5e1" },
];

const hex = (h: string): [number, number, number] => {
  const v = parseInt(h.replace("#", ""), 16);
  return [((v >> 16) & 255) / 255, ((v >> 8) & 255) / 255, (v & 255) / 255];
};
const mix = (a: number[], b: number[], t: number) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];

const POINT_VERT = /* glsl */ `
  attribute vec3 aColor;
  attribute float aSize;
  attribute float aSeed;
  uniform float uTime;
  uniform float uPixelRatio;
  uniform float uSize;
  uniform float uScanY;
  uniform float uScanW;
  uniform float uAudio;
  varying vec3 vColor;
  varying float vGlow;
  void main() {
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    float scan = exp(-pow((position.y - uScanY) / uScanW, 2.0));
    float tw = 0.93 + 0.07 * sin(uTime * 2.2 + aSeed * 6.2831);
    vGlow = scan;
    vColor = aColor * (tw + scan * 0.22 + uAudio * 0.5);
    gl_PointSize = uSize * aSize * (1.0 + scan * 0.12 + uAudio * 0.35) * uPixelRatio * (260.0 / -mv.z);
    gl_Position = projectionMatrix * mv;
  }
`;
const POINT_FRAG = /* glsl */ `
  uniform float uOpacity;
  varying vec3 vColor;
  varying float vGlow;
  void main() {
    vec2 c = gl_PointCoord - 0.5;
    float d = length(c);
    if (d > 0.5) discard;
    float core = smoothstep(0.5, 0.0, d);
    float a = pow(core, 1.7) + smoothstep(0.16, 0.0, d) * 0.6;
    gl_FragColor = vec4(vColor * (0.85 + vGlow * 0.3), a * uOpacity);
  }
`;
const LINE_VERT = /* glsl */ `
  attribute vec3 aColor;
  uniform float uScanY;
  uniform float uScanW;
  varying vec3 vColor;
  void main() {
    float scan = exp(-pow((position.y - uScanY) / (uScanW * 1.6), 2.0));
    vColor = aColor * (1.0 + scan * 2.2);
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;
const LINE_FRAG = /* glsl */ `
  uniform float uOpacity;
  varying vec3 vColor;
  void main() { gl_FragColor = vec4(vColor, uOpacity); }
`;

export type EngineOptions = {
  source: PortraitSource;
  count?: number;
  onReady?: () => void;
  onModeChange?: (mode: Mode) => void;
};

export type Engine = ReturnType<typeof createEngine>;

export function createEngine(THREE: typeof THREE_NS, canvas: HTMLCanvasElement, opts: EngineOptions) {
  const isSmall = window.innerWidth < 720;
  const total = opts.count ?? (isSmall ? 14000 : 26000);

  const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true, powerPreference: "high-performance" });
  renderer.setClearColor(0x000000, 0);
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(50, 1, 0.1, 2000);
  const view = { yaw: 0, pitch: 0, distance: 120, targetYaw: 0, targetPitch: 0, targetDistance: 120, autoRotate: false };

  const group = new THREE.Group();
  scene.add(group);

  // ---------- Modelo ----------
  const F: FaceModel = generate(opts.source, total);
  const rig: Rig = createRig(F);
  const n = F.count;
  const positions = new Float32Array(n * 3);
  const velocities = new Float32Array(n * 3);
  const colors = new Float32Array(n * 3);
  const sizes = new Float32Array(n);
  const seeds = new Float32Array(n);

  // Arranque: nube esférica que se condensa en el rostro.
  for (let i = 0; i < n; i += 1) {
    const th = Math.random() * Math.PI * 2;
    const ph = Math.acos(2 * Math.random() - 1);
    const r = 40 + Math.cbrt(Math.random()) * 140;
    positions[i * 3] = r * Math.sin(ph) * Math.cos(th);
    positions[i * 3 + 1] = r * Math.sin(ph) * Math.sin(th);
    positions[i * 3 + 2] = r * Math.cos(ph) * 0.6;
    sizes[i] = F.size[i];
    seeds[i] = F.seed[i];
  }

  // Bases de las formaciones alternativas.
  const sphere = new Float32Array(n * 3);
  const fib = new Float32Array(n * 3);
  const lorenz = new Float32Array(n * 3);
  {
    for (let i = 0; i < n; i += 1) {
      const th = Math.random() * Math.PI * 2;
      const ph = Math.acos(2 * Math.random() - 1);
      const r = Math.cbrt(Math.random());
      sphere[i * 3] = r * Math.sin(ph) * Math.cos(th);
      sphere[i * 3 + 1] = r * Math.sin(ph) * Math.sin(th);
      sphere[i * 3 + 2] = r * Math.cos(ph);
      const y = 1 - (i / (n - 1)) * 2;
      const rad = Math.sqrt(1 - y * y);
      const a = i * 2.399963;
      fib[i * 3] = Math.cos(a) * rad;
      fib[i * 3 + 1] = y;
      fib[i * 3 + 2] = Math.sin(a) * rad;
    }
    let x = 0.1;
    let y = 0;
    let z = 0;
    const dt = 0.006;
    for (let k = 0; k < 600; k += 1) {
      const dx = 10 * (y - x);
      const dy = x * (28 - z) - y;
      const dz = x * y - (8 / 3) * z;
      x += dx * dt;
      y += dy * dt;
      z += dz * dt;
    }
    for (let i = 0; i < n; i += 1) {
      for (let s = 0; s < 3; s += 1) {
        const dx = 10 * (y - x);
        const dy = x * (28 - z) - y;
        const dz = x * y - (8 / 3) * z;
        x += dx * dt;
        y += dy * dt;
        z += dz * dt;
      }
      lorenz[i * 3] = x / 22;
      lorenz[i * 3 + 1] = (z - 25) / 22;
      lorenz[i * 3 + 2] = y / 22;
    }
  }

  // ---------- Geometría de puntos ----------
  const geometry = new THREE.BufferGeometry();
  const posAttr = new THREE.BufferAttribute(positions, 3);
  posAttr.setUsage(THREE.DynamicDrawUsage);
  geometry.setAttribute("position", posAttr);
  geometry.setAttribute("aColor", new THREE.BufferAttribute(colors, 3));
  geometry.setAttribute("aSize", new THREE.BufferAttribute(sizes, 1));
  geometry.setAttribute("aSeed", new THREE.BufferAttribute(seeds, 1));
  const uniforms = {
    uTime: { value: 0 },
    uPixelRatio: { value: 1 },
    uSize: { value: isSmall ? 0.95 : 0.85 },
    uScanY: { value: 100 },
    uScanW: { value: 3 },
    uAudio: { value: 0 },
    uOpacity: { value: 0.92 },
  };
  const material = new THREE.ShaderMaterial({
    uniforms,
    vertexShader: POINT_VERT,
    fragmentShader: POINT_FRAG,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const points = new THREE.Points(geometry, material);
  points.frustumCulled = false;
  group.add(points);

  // ---------- Malla neural ----------
  const E = F.rest.length;
  const linePos = new Float32Array(E * 6);
  const lineCol = new Float32Array(E * 6);
  const lineGeo = new THREE.BufferGeometry();
  const linePosAttr = new THREE.BufferAttribute(linePos, 3);
  linePosAttr.setUsage(THREE.DynamicDrawUsage);
  const lineColAttr = new THREE.BufferAttribute(lineCol, 3);
  lineColAttr.setUsage(THREE.DynamicDrawUsage);
  lineGeo.setAttribute("position", linePosAttr);
  lineGeo.setAttribute("aColor", lineColAttr);
  const lineUniforms = { uScanY: uniforms.uScanY, uScanW: uniforms.uScanW, uOpacity: { value: 0.55 } };
  const lineMat = new THREE.ShaderMaterial({
    uniforms: lineUniforms,
    vertexShader: LINE_VERT,
    fragmentShader: LINE_FRAG,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const lines = new THREE.LineSegments(lineGeo, lineMat);
  lines.frustumCulled = false;
  group.add(lines);

  // ---------- Polvo de fondo ----------
  const dustN = isSmall ? 500 : 900;
  const dustPos = new Float32Array(dustN * 3);
  const dustCol = new Float32Array(dustN * 3);
  const dustSize = new Float32Array(dustN);
  const dustSeed = new Float32Array(dustN);
  for (let i = 0; i < dustN; i += 1) {
    dustPos[i * 3] = (Math.random() - 0.5) * 420;
    dustPos[i * 3 + 1] = (Math.random() - 0.5) * 260;
    dustPos[i * 3 + 2] = -60 - Math.random() * 220;
    dustSize[i] = 0.6 + Math.random() * 1.2;
    dustSeed[i] = Math.random();
  }
  const dustGeo = new THREE.BufferGeometry();
  dustGeo.setAttribute("position", new THREE.BufferAttribute(dustPos, 3));
  dustGeo.setAttribute("aColor", new THREE.BufferAttribute(dustCol, 3));
  dustGeo.setAttribute("aSize", new THREE.BufferAttribute(dustSize, 1));
  dustGeo.setAttribute("aSeed", new THREE.BufferAttribute(dustSeed, 1));
  const dustUniforms = { ...uniforms, uScanY: { value: 9999 }, uAudio: { value: 0 }, uOpacity: { value: 0.5 } };
  const dustMat = new THREE.ShaderMaterial({
    uniforms: dustUniforms,
    vertexShader: POINT_VERT,
    fragmentShader: POINT_FRAG,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const dust = new THREE.Points(dustGeo, dustMat);
  dust.frustumCulled = false;
  scene.add(dust);

  // ---------- Paleta ----------
  let paletteIndex = 0;
  let lineBase = [0.1, 0.4, 0.3];
  let lineTarget = 0.3;
  function applyPalette(idx: number) {
    paletteIndex = ((idx % PALETTES.length) + PALETTES.length) % PALETTES.length;
    const P = PALETTES[paletteIndex];
    const sw = P.colors.map(hex);
    const lip = hex(P.lip);
    const accent = hex(P.line);
    const ramp = (l: number) =>
      l < 0.34 ? mix(sw[0], sw[1], l / 0.34) : l < 0.68 ? mix(sw[1], sw[2], (l - 0.34) / 0.34) : mix(sw[2], sw[3], (l - 0.68) / 0.32);
    for (let i = 0; i < n; i += 1) {
      const ix = i * 3;
      const k = F.kind[i];
      let c: number[];
      if (k === KIND.halo) {
        const t = F.tone[i];
        c = (P.natural ? (t < 0.5 ? accent : hex("#e8c48a")) : sw[1 + (Math.floor(t * 3) % 3)]).map((v) => v * 0.38);
      } else if (P.natural) {
        const r = F.color[ix];
        const g = F.color[ix + 1];
        const b = F.color[ix + 2];
        // Color real de la foto con un leve velo neural en las sombras.
        const veil = 0.05 * (1 - F.shade[i]);
        c = [Math.pow(r, 1.22) * 1.55 + accent[0] * veil, Math.pow(g, 1.22) * 1.55 + accent[1] * veil, Math.pow(b, 1.22) * 1.55 + accent[2] * veil];
      } else {
        const l = Math.min(1, Math.max(0, (F.shade[i] - 0.06) * 1.18));
        c = ramp(l);
        if (k === KIND.lip) {
          // Solo tiñe los píxeles realmente rojizos del labio (no los dientes ni la piel de la caja).
          const cr = F.color[ix];
          const rg = (cr - F.color[ix + 1]) / Math.max(cr, 0.001);
          // Piel ≈ 0.30–0.38, labios ≈ 0.42–0.5 en la foto: tiñe solo el labio real.
          const w = Math.min(1, Math.max(0, (rg - 0.4) / 0.08)) * (cr > 0.3 ? 1 : 0);
          c = mix(c, lip.map((v) => v * (0.45 + 0.6 * l)), 0.4 * w);
        }
        if (k === KIND.iris) c = mix(c, sw[2], 0.35);
      }
      colors[ix] = c[0];
      colors[ix + 1] = c[1];
      colors[ix + 2] = c[2];
    }
    (geometry.attributes.aColor as THREE_NS.BufferAttribute).needsUpdate = true;
    lineBase = accent.map((v) => v * 0.22);
    lineTarget = P.natural ? 0.16 : 0.42;
    for (let i = 0; i < dustN; i += 1) {
      const c = sw[i % 4];
      dustCol[i * 3] = c[0] * 0.5;
      dustCol[i * 3 + 1] = c[1] * 0.5;
      dustCol[i * 3 + 2] = c[2] * 0.5;
    }
    (dustGeo.attributes.aColor as THREE_NS.BufferAttribute).needsUpdate = true;
  }
  applyPalette(0);

  // ---------- Layout ----------
  let width = 1;
  let height = 1;
  let shiftX = 0;
  let shiftY = 0;
  function resize() {
    const rect = canvas.getBoundingClientRect();
    width = Math.max(1, rect.width || window.innerWidth);
    height = Math.max(1, rect.height || window.innerHeight);
    const pr = Math.min(window.devicePixelRatio || 1, 1.75);
    renderer.setPixelRatio(pr);
    renderer.setSize(width, height, false);
    uniforms.uPixelRatio.value = pr;
    camera.aspect = width / height;
    const hh = view.targetDistance * Math.tan((camera.fov * Math.PI) / 360);
    const hw = hh * camera.aspect;
    const wide = width >= 1024 && camera.aspect > 1.15;
    if (wide) {
      rig.scale = Math.min(hh * 0.66, hw * 0.4);
      shiftX = 0.42 * (width / 2);
      shiftY = 0.1 * (height / 2);
    } else {
      rig.scale = Math.min(hh * 0.42, hw * 0.8);
      shiftX = 0;
      shiftY = Math.min(0.44, 0.92 - rig.scale * 1.15 / hh) * (height / 2);
    }
    // Lente desplazada: el rostro queda a un lado del texto y la órbita gira sobre ella.
    camera.setViewOffset(width, height, -shiftX, shiftY, width, height);
    camera.updateProjectionMatrix();
    uniforms.uScanW.value = rig.scale * 0.1;
    // Tamaño de punto ≈ separación de la rejilla, para que el retrato se lea como foto.
    uniforms.uSize.value = (2.05 * F.spacing * rig.scale * height) / (2 * Math.tan((camera.fov * Math.PI) / 360) * 260);
  }

  function updateCamera() {
    const cp = Math.cos(view.pitch);
    camera.position.set(
      view.distance * Math.sin(view.yaw) * cp,
      view.distance * Math.sin(view.pitch),
      view.distance * Math.cos(view.yaw) * cp,
    );
    camera.lookAt(0, 0, 0);
  }

  // ---------- Interacción ----------
  const raycaster = new THREE.Raycaster();
  const plane = new THREE.Plane(new THREE.Vector3(0, 0, 1), 0);
  const ndc = new THREE.Vector2();
  const hit = new THREE.Vector3();
  const pointer = { x: 0, y: 0, active: false, worldX: 0, worldY: 0 };
  const drag = { id: -1, button: -1, x: 0, y: 0, moved: false };

  function toWorld(clientX: number, clientY: number) {
    const box = canvas.getBoundingClientRect();
    ndc.set(((clientX - box.left) / box.width) * 2 - 1, -((clientY - box.top) / box.height) * 2 + 1);
    raycaster.setFromCamera(ndc, camera);
    const p = raycaster.ray.intersectPlane(plane, hit);
    return p ? { x: p.x - group.position.x, y: p.y - group.position.y } : { x: 0, y: 0 };
  }

  const isUi = (t: EventTarget | null) => t instanceof Element && !!t.closest("[data-ui]");

  function onMove(e: PointerEvent) {
    pointer.x = e.clientX;
    pointer.y = e.clientY;
    pointer.active = true;
    if (drag.id === e.pointerId) {
      const dx = e.clientX - drag.x;
      const dy = e.clientY - drag.y;
      if (Math.abs(dx) + Math.abs(dy) > 3) drag.moved = true;
      if (drag.button === 2 || (drag.button === 0 && e.pointerType !== "mouse" && drag.moved)) {
        view.targetYaw -= dx * 0.006;
        view.targetPitch = Math.max(-1, Math.min(1, view.targetPitch + dy * 0.006));
      }
      drag.x = e.clientX;
      drag.y = e.clientY;
    }
  }
  function onLeave() {
    pointer.active = false;
  }
  function onDown(e: PointerEvent) {
    if (isUi(e.target)) return;
    drag.id = e.pointerId;
    drag.button = e.button;
    drag.x = e.clientX;
    drag.y = e.clientY;
    drag.moved = false;
  }
  function onUp(e: PointerEvent) {
    if (drag.id !== e.pointerId) return;
    if (drag.button === 0 && !drag.moved && !isUi(e.target)) api.burstAt(e.clientX, e.clientY);
    drag.id = -1;
    drag.button = -1;
  }
  function onContext(e: MouseEvent) {
    if (!isUi(e.target)) e.preventDefault();
  }
  function onWheel(e: WheelEvent) {
    if (isUi(e.target)) return;
    view.targetDistance = Math.max(55, Math.min(260, view.targetDistance * (1 + Math.sign(e.deltaY) * 0.08)));
  }
  function onDbl(e: MouseEvent) {
    if (isUi(e.target)) return;
    api.resetView();
  }

  window.addEventListener("pointermove", onMove);
  window.addEventListener("pointerdown", onDown);
  window.addEventListener("pointerup", onUp);
  window.addEventListener("pointercancel", onUp);
  document.addEventListener("pointerleave", onLeave);
  window.addEventListener("contextmenu", onContext);
  window.addEventListener("wheel", onWheel, { passive: true });
  window.addEventListener("dblclick", onDbl);
  window.addEventListener("resize", resize);

  // ---------- Audio (micrófono) ----------
  let analyser: AnalyserNode | null = null;
  let audioCtx: AudioContext | null = null;
  let micStream: MediaStream | null = null;
  let audioData: Uint8Array<ArrayBuffer> | null = null;
  let audioLevel = 0;

  // ---------- Bucle ----------
  let mode: Mode = "face";
  let frame = 0;
  let last = performance.now();
  let elapsed = 0;
  let dead = false;
  let readyFired = false;

  function formationTarget(i: number, time: number, out: [number, number, number]) {
    const S = rig.S;
    const ix = i * 3;
    switch (mode) {
      case "vortex": {
        const arm = i % 3;
        const u = (i * 0.618034) % 1;
        const r = Math.sqrt(u) * S * 1.7 + 2;
        const a = arm * ((Math.PI * 2) / 3) + r * 0.075 + time * (0.35 - u * 0.15);
        out[0] = Math.cos(a) * r;
        out[1] = Math.sin(a) * r * 0.55 + sphere[ix + 1] * S * 0.12;
        out[2] = Math.sin(a) * r * 0.6 + sphere[ix + 2] * S * 0.25;
        break;
      }
      case "supernova": {
        const shell = 1 + ((i * 0.381966) % 1) * 0.9;
        const pulse = 1 + 0.18 * Math.sin(time * 2.2 - shell * 3);
        const r = S * 1.25 * shell * pulse;
        const a = time * 0.15;
        const x = fib[ix];
        const z = fib[ix + 2];
        out[0] = (x * Math.cos(a) - z * Math.sin(a)) * r;
        out[1] = fib[ix + 1] * r;
        out[2] = (x * Math.sin(a) + z * Math.cos(a)) * r;
        break;
      }
      case "lorenz": {
        const a = time * 0.2;
        const x = lorenz[ix];
        const z = lorenz[ix + 2];
        out[0] = (x * Math.cos(a) - z * Math.sin(a)) * S * 1.25;
        out[1] = lorenz[ix + 1] * S * 1.25;
        out[2] = (x * Math.sin(a) + z * Math.cos(a)) * S * 1.25;
        break;
      }
      default: {
        const a = time * 0.12;
        const R = S * 1.9;
        const x = sphere[ix];
        const z = sphere[ix + 2];
        const wob = 1 + 0.06 * Math.sin(time * 1.3 + i * 0.01);
        out[0] = (x * Math.cos(a) - z * Math.sin(a)) * R * wob;
        out[1] = sphere[ix + 1] * R * wob;
        out[2] = (x * Math.sin(a) + z * Math.cos(a)) * R * 0.7;
      }
    }
    return out;
  }

  const tmp: [number, number, number] = [0, 0, 0];

  function step(now: number) {
    if (dead) return;
    frame = requestAnimationFrame(step);
    const dt = Math.min(0.05, Math.max(0.001, (now - last) / 1000));
    last = now;
    elapsed += dt;
    const d60 = dt * 60;

    // Audio
    if (analyser && audioData) {
      analyser.getByteFrequencyData(audioData);
      let sum = 0;
      const lim = Math.min(audioData.length, 64);
      for (let k = 2; k < lim; k += 1) sum += audioData[k];
      const lvl = sum / (lim - 2) / 255;
      audioLevel += (Math.max(0, lvl - 0.04) * 1.6 - audioLevel) * Math.min(1, d60 * 0.3);
    } else audioLevel *= 0.9;
    rig.audio = audioLevel;
    uniforms.uAudio.value = audioLevel;

    // Cámara
    if (view.autoRotate) view.targetYaw += dt * 0.25;
    view.yaw += (view.targetYaw - view.yaw) * Math.min(1, d60 * 0.08);
    view.pitch += (view.targetPitch - view.pitch) * Math.min(1, d60 * 0.08);
    view.distance += (view.targetDistance - view.distance) * Math.min(1, d60 * 0.08);
    updateCamera();

    // Puntero en el plano del rostro
    let mx = 0;
    let my = 0;
    if (pointer.active) {
      const w = toWorld(pointer.x, pointer.y);
      mx = w.x;
      my = w.y;
      pointer.worldX = mx;
      pointer.worldY = my;
    }

    const isFace = mode === "face";
    rig.prepare(elapsed, dt, mx, my - rig.S * 0.15, pointer.active);
    const S = rig.S;
    const kSpring = isFace ? 0.0058 : 0.0034;
    const damping = Math.pow(0.915, d60);
    const hoverR = S * (isFace ? 0.24 : 0.42);
    const hoverR2 = hoverR * hoverR;

    for (let i = 0; i < n; i += 1) {
      const ix = i * 3;
      const px = positions[ix];
      const py = positions[ix + 1];
      const pz = positions[ix + 2];
      const t = isFace ? rig.target(i) : formationTarget(i, elapsed, tmp);
      let ax = (t[0] - px) * kSpring;
      let ay = (t[1] - py) * kSpring;
      let az = (t[2] - pz) * kSpring;
      if (!isFace) {
        // Remolino suave + turbulencia (familias de campo del motor neural).
        ax += -py * 0.00025 + Math.sin(py * 0.05 + elapsed * 1.6 + i) * 0.004;
        ay += px * 0.00025 + Math.cos(px * 0.05 - elapsed + i) * 0.004;
      }
      if (pointer.active) {
        const dx = px - mx;
        const dy = py - my;
        const d2 = dx * dx + dy * dy;
        if (d2 < hoverR2 && d2 > 0.01) {
          const d = Math.sqrt(d2);
          const f = (1 - d / hoverR) * (isFace ? 0.035 : 0.2);
          ax += (dx / d) * f;
          ay += (dy / d) * f;
          az += f * 0.6;
        }
      }
      if (audioLevel > 0.02 && F.group[i] === GROUP.halo) {
        az += Math.sin(elapsed * 10 + i) * audioLevel * 0.08;
      }
      let vx = (velocities[ix] + ax * d60) * damping;
      let vy = (velocities[ix + 1] + ay * d60) * damping;
      let vz = (velocities[ix + 2] + az * d60) * damping;
      velocities[ix] = vx;
      velocities[ix + 1] = vy;
      velocities[ix + 2] = vz;
      positions[ix] = px + vx * d60;
      positions[ix + 1] = py + vy * d60;
      positions[ix + 2] = pz + vz * d60;
      vx = vy = vz = 0;
    }
    posAttr.needsUpdate = true;

    // Malla
    if (isFace) {
      lines.visible = true;
      lineUniforms.uOpacity.value += (lineTarget - lineUniforms.uOpacity.value) * 0.05;
      const ed = F.edges;
      const rest = F.rest;
      const b = lineBase;
      const scaleZ = 1;
      for (let e = 0; e < E; e += 1) {
        const a = ed[e * 2] * 3;
        const c = ed[e * 2 + 1] * 3;
        const o = e * 6;
        const ax = positions[a];
        const ay = positions[a + 1];
        const az = positions[a + 2];
        const bx = positions[c];
        const by = positions[c + 1];
        const bz = positions[c + 2];
        linePos[o] = ax;
        linePos[o + 1] = ay;
        linePos[o + 2] = az;
        linePos[o + 3] = bx;
        linePos[o + 4] = by;
        linePos[o + 5] = bz;
        let w = 1.6 - (Math.hypot(ax - bx, ay - by, az - bz) / (rest[e] * S * scaleZ)) * 0.6;
        w = w < 0 ? 0 : w > 1 ? 1 : w;
        w *= 0.35 + 0.65 * Math.min(1, (F.shade[a / 3] + F.shade[c / 3]) * 0.5);
        lineCol[o] = lineCol[o + 3] = b[0] * w;
        lineCol[o + 1] = lineCol[o + 4] = b[1] * w;
        lineCol[o + 2] = lineCol[o + 5] = b[2] * w;
      }
      linePosAttr.needsUpdate = true;
      lineColAttr.needsUpdate = true;
    } else {
      lineUniforms.uOpacity.value *= 0.85;
      if (lineUniforms.uOpacity.value < 0.01) lines.visible = false;
    }

    // Barrido de escaneo
    const period = 7.5;
    const ph = (elapsed % period) / period;
    uniforms.uScanY.value = isFace ? S * 1.8 - ph * S * 4.2 : 9999;
    uniforms.uTime.value = elapsed;
    dustUniforms.uTime.value = elapsed;
    dust.rotation.y = Math.sin(elapsed * 0.05) * 0.1;

    renderer.render(scene, camera);
    if (!readyFired && elapsed > 0.15) {
      readyFired = true;
      opts.onReady?.();
    }
  }

  const api = {
    get mode() {
      return mode;
    },
    get palette() {
      return paletteIndex;
    },
    setMode(m: Mode) {
      if (m === mode) return;
      mode = m;
      if (m !== "face") {
        for (let i = 0; i < n * 3; i += 1) velocities[i] += (Math.random() - 0.5) * 1.6;
      }
      opts.onModeChange?.(m);
    },
    setPalette(idx: number) {
      applyPalette(idx);
    },
    setExpression(e: Expression) {
      rig.expression = e;
    },
    speak(on: boolean) {
      rig.speaking = on;
    },
    burstAt(clientX: number, clientY: number) {
      const w = toWorld(clientX, clientY);
      rig.burst(positions, velocities, n, w.x, w.y);
    },
    burstCenter() {
      rig.burst(positions, velocities, n, 0, rig.S * 0.15);
    },
    resetView() {
      view.targetYaw = 0;
      view.targetPitch = 0;
      view.targetDistance = 120;
      view.autoRotate = false;
    },
    toggleAutoRotate() {
      view.autoRotate = !view.autoRotate;
      return view.autoRotate;
    },
    zoom(dir: 1 | -1) {
      view.targetDistance = Math.max(55, Math.min(260, view.targetDistance * (dir > 0 ? 0.88 : 1.12)));
    },
    async enableMic() {
      if (analyser) return true;
      try {
        micStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
        const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        audioCtx = new Ctx();
        analyser = audioCtx.createAnalyser();
        analyser.fftSize = 256;
        analyser.smoothingTimeConstant = 0.6;
        audioCtx.createMediaStreamSource(micStream).connect(analyser);
        audioData = new Uint8Array(new ArrayBuffer(analyser.frequencyBinCount));
        return true;
      } catch {
        return false;
      }
    },
    disableMic() {
      micStream?.getTracks().forEach((t) => t.stop());
      audioCtx?.close().catch(() => undefined);
      micStream = null;
      audioCtx = null;
      analyser = null;
      audioData = null;
    },
    get audioLevel() {
      return audioLevel;
    },
    destroy() {
      dead = true;
      cancelAnimationFrame(frame);
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerdown", onDown);
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointercancel", onUp);
      document.removeEventListener("pointerleave", onLeave);
      window.removeEventListener("contextmenu", onContext);
      window.removeEventListener("wheel", onWheel);
      window.removeEventListener("dblclick", onDbl);
      window.removeEventListener("resize", resize);
      api.disableMic();
      geometry.dispose();
      material.dispose();
      lineGeo.dispose();
      lineMat.dispose();
      dustGeo.dispose();
      dustMat.dispose();
      renderer.dispose();
    },
  };

  resize();
  view.distance = view.targetDistance;
  updateCamera();
  frame = requestAnimationFrame(step);
  return api;
}
