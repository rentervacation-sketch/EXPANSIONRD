<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Project rules
- The Virginia particle face lives in `src/lib/virginia/` (`portrait.ts` = photo-sampled particle model + rig, built at runtime from `src/assets/virginia-portrait.webp` (color) and `virginia-depth.webp` (aligned depth map); `engine.ts` = Three.js engine) and is loaded with a dynamic `import()` inside `useEffect`, because WebGL/`three` must never run during SSR.
- `portrait.ts` and `engine.ts` carry `// @ts-nocheck`: tight typed-array loops conflict with `noUncheckedIndexedAccess`; keep UI/React code fully type-checked and keep these modules free of DOM-framework logic.
- UI controls over the canvas must carry the `data-ui` attribute so clicks on them don't trigger the particle burst or camera drag.
- Virginia's likeness comes from her real photo, never from procedural/cartoon geometry; rig regions (eyes, brows, mouth, jaw) are landmark constants measured on the 1024px reference in `portrait.ts`, so replacing the photo requires re-measuring them.
