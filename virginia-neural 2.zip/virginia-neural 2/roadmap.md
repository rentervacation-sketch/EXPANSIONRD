# Roadmap

- [x] Rostro de Virginia en partículas desde su foto real (no caricatura)
- [x] Ajuste de contraste, borde rostro/cabello, tinte de labios y apertura de boca sin "raja"
- [ ] ZIP restaurable (<20 MB): sitio completo + recursos de la imagen de partículas + notas de investigación
- [ ] Busto 3D completo (hombros a cabeza, visible desde todos los ángulos)
- [ ] Movimientos naturales al hablar (cabeza, mandíbula/labios, parpadeo, cejas, respiración de hombros)
