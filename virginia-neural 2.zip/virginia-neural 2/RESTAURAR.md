# Cómo restaurar el sitio de Virginia

Requisitos: Node.js 20+ o Bun 1.1+.

```bash
cd virginia-neural
bun install          # o: npm install
bun run dev          # o: npm run dev  → abre la URL que muestre la terminal
bun run build        # compilación de producción (opcional)
```

Para volver a llevarlo a Lovable: crea un proyecto, conéctalo a GitHub y sube el contenido de esta carpeta al repositorio.

## Estructura

- `src/lib/virginia/portrait.ts` — arma el rostro de partículas desde la foto real.
- `src/lib/virginia/engine.ts` — motor 3D (Three.js): física, formaciones, paletas, malla neural.
- `src/components/virginia/VirginiaStage.tsx` — página, botones, voz y micrófono.
- `src/assets/virginia-portrait.webp` / `virginia-depth.webp` — foto (con transparencia) y profundidad que usa el sitio.
- `recursos-virginia/` — referencias originales, proceso de la imagen, scripts, capturas y notas. No se necesita para que el sitio funcione.
